import * as yup from "yup";

export const loginValidation = yup.object().shape({
  email: yup
    .string()
    .trim()
    .required("Email is required.")
    .email("Invalid email format.")
    .min(3, "Email must be at least 3 characters.")
    .max(200, "Email must not exceed 200 characters."),
  password: yup
    .string()
    .trim()
    .required("Password is required.")
    .min(8, "Password must be at least 8 characters.")
    .max(255, "Password must not exceed 255 characters."),
});

export const signupValidation = yup.object().shape({
  firstname: yup
    .string()
    .trim()
    .required("First name is required.")
    .min(3, "First name must be at least 3 characters.")
    .max(50, "First name must not exceed 50 characters."),
  lastname: yup
    .string()
    .trim()
    .nullable()
    .notRequired()
    .max(50, "Last name must not exceed 50 characters."),
  email: yup
    .string()
    .trim()
    .required("Email is required.")
    .email("Invalid email format.")
    .min(3, "Email must be at least 3 characters.")
    .max(200, "Email must not exceed 200 characters."),
  password: yup
    .string()
    .trim()
    .required("Password is required.")
    .min(8, "Password must be at least 8 characters.")
    .max(255, "Password must not exceed 255 characters."),
  confirmPassword: yup
    .string()
    .trim()
    .oneOf([yup.ref("password"), null], "Passwords must match.")
    .required("Confirm Password field is required"),
  terms: yup
    .boolean()
    .oneOf([true], "You must accept the terms and conditions.")
    .required("You must accept the terms and conditions."),
});

export const resetPasswordValidation = yup.object().shape({
  email: yup
    .string()
    .trim()
    .required("Email is required.")
    .email("Invalid email format.")
    .min(3, "Email must be at least 3 characters.")
    .max(200, "Email must not exceed 200 characters."),
});

export const changePasswordValidation = yup.object().shape({
  password: yup
    .string()
    .trim()
    .required("Password is required.")
    .min(8, "Password must be at least 8 characters.")
    .max(255, "Password must not exceed 255 characters."),
  confirmPassword: yup
    .string()
    .trim()
    .oneOf([yup.ref("password"), null], "Passwords must match.")
    .required("Confirm Password field is required"),
});

export const ProfileSchema = yup.object().shape({
  firstname: yup
    .string()
    .trim()
    .required("First name is required.")
    .min(3, "First name must be at least 3 characters.")
    .max(50, "First name must not exceed 50 characters."),
  lastname: yup
    .string()
    .trim()
    .nullable()
    .notRequired()
    .max(50, "Last name must not exceed 50 characters."),
  email: yup
    .string()
    .trim()
    .required("Email is required.")
    .email("Invalid email format.")
    .min(3, "Email must be at least 3 characters.")
    .max(200, "Email must not exceed 200 characters."),
  password: yup
    .string()
    .trim()
    .required("Password is required.")
    .min(8, "Password must be at least 8 characters.")
    .max(255, "Password must not exceed 255 characters."),
  confirmPassword: yup
    .string()
    .trim()
    .required("Confirm Password field is required"),
    organization: yup
    .string()
    .nullable()
    .notRequired()
    .max(50, "Organization name must not exceed 50 characters."),
});
