import { getToken } from 'next-auth/jwt';
import { NextResponse } from 'next/server';

export async function middleware(req) {
  const { pathname } = req.nextUrl;

  

  // Retrieve the session using next-auth's getToken method
  const session = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

  console.log( "session in middleware",  session);

  // Check if the user is logged in
  const isLoggedIn = !!session;

  console.log( "isLoggedIn in middleware",  isLoggedIn);


  // Redirect logged-in users away from login or signup pages
  if (isLoggedIn && (pathname === '/login' || pathname === '/signup')) {
    return NextResponse.redirect(new URL('/', req.url));
  }

  // Redirect unauthenticated users to the login page if they try to access restricted pages
  if (!isLoggedIn && (pathname === '/license' || pathname === '/profile' || pathname === '/paymenthistory')) {
    return NextResponse.redirect(new URL('/login', req.url));
  }

  // Proceed normally for other cases
  return NextResponse.next();
}

export const config = {
  matcher: ['/login', '/signup', '/license/:path*', '/profile' , '/paymenthistory'],
};
