import React from "react";
import {
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  useDisclosure,
  Checkbox,
  Input,
  Link,
} from "@nextui-org/react";

export default function AlerModal({
  isOpen,
  onOpen,
  onOpenChange,
  onDone,
  title,
  desc,
}) {
  return (
    <>
      <Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="center">
        <ModalContent className="text-black py-6">
          {(onClose) => (
            <>
              <ModalBody>
                <div className=" py-3 px-1 text-center">
                  <h3 className="text-xl font-bold">{title}</h3>
                  <p className="text-gray-600 text-wrap font-lg py-4">{desc}</p>
                </div>
                <div className="flex justify-center gap-2">
                  <button
                    className="relative inline-flex items-center rounded-none justify-center overflow-hidden  p-[1px] uppercase"
                    onClick={onClose}
                  >
                    <span className="absolute inset-0 bg-gradient-to-r from-[#1BD1D8] via-[#F06BDA] to-[#E2CBFF] "></span>
                    <span className="relative inline-flex items-center justify-center gap-2  bg-white px-10  py-[7px] text-medium font-medium text-black backdrop-blur-md">
                      No
                    </span>
                  </button>
                  <Button
                    className="rounded-none uppercase bg-[#1BD1D8] text-black text-medium  font-medium px-10"
                    onPress={onDone}
                  >
                    Yes
                  </Button>
                </div>
              </ModalBody>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
}
