"use client";
import { FacebookIcon } from "@/app/assets/icon/FacebookIcon";
import { InstagramIcon } from "@/app/assets/icon/IntagramIcon";
import { LinkeinIcon } from "@/app/assets/icon/LinkeinIcon";
import { YoutubeIcon } from "@/app/assets/icon/YoutubeIcon";
import Image from "next/image";
import Link from "next/link";

const Quick_links = [
  {
    title: "Quick Links",
    items: [
      { name: "Home", link: "/" },
      { name: "Subscription Plans", link: "/plans" },
      { name: "Manage License", link: "/license" },
      // { name: "About Us", link: "about-us" },
      // { name: "Contact Us", link: "about-us" },
    ],
  },
];
const Reach_links = [
  {
    title: "Got questions?",
    items: [
      {
        title: "Reach out at",
        value: "info@legaltype.com",
        link: "mailto:info@legaltype.com",
      },
      {
        title: "Address",
        value: (
          <>
            LegalType
            <br />
            1043 Garland Ave Unit C #1272
            <br />
            San Jose, CA 95126 USA
          </>
        ),
        link: "https://maps.app.goo.gl/rNV3qjSDZfym6dMi8",
      },
    ],
  },
];

const currentYear = new Date().getFullYear();

export default function Footer() {
  const handleDownloadAndOpen = (url, fileName) => {
    // Open the file in a new tab
    window.open(url, "_blank");

    // Create a temporary anchor tag to trigger the download
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName); // Specify the filename for the download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link); // Remove the link after triggering the download
  };

  return (
    <footer className="relative w-full bg-[#F6F6F6] text-black">
      <div className="mx-auto w-full  p-8 lg:px-16">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          {/* Logo and Description */}
          <div className="flex flex-col items-center md:items-start w-full md:w-1/3 p-0 md:pr-8">
            <Image src="/images/logo.svg" alt="logo" height="200" width="200" />
            <p className="font-medium text-sm opacity-80 mt-4 text-center md:text-left w-full break-normal">
              We help lawyers type faster with less effort, so they can focus
              more on winning.
            </p>
          </div>

          {/* Links Section */}
          <div className="flex justify-between gap-4 w-full md:w-2/3">
            <ul className="w-full ">
              <h6 className="mb-3 text-medium font-semibold text-black">
                Download Links
              </h6>

              {/* <li>
                <Link href="/"

                  className="block py-1.5 text-sm font-normal opacity-80 transition-colors hover:opacity-100"
                >
                  Software
                </Link>
              </li> */}

              <li>
                <a
                  href="/images/LegalType_Manual_Web.PNG"
                  className="block py-1.5 text-sm font-normal text-black transition-colors hover:opacity-100"
                  onClick={(e) => {
                    e.preventDefault(); // Prevent default anchor behavior
                    handleDownloadAndOpen(
                      "/images/LegalType_Manual_Web.PNG",
                      "LegalType_Manual.png"
                    );
                  }}
                >
                  Keyboard Manual
                </a>
              </li>

              <li>
                <a
                  href="/images/LegalType IT Security Specifications.pdf"
                  className="block py-1.5 text-sm font-normal text-black transition-colors hover:opacity-100"
                  onClick={(e) => {
                    e.preventDefault(); // Prevent default anchor behavior
                    handleDownloadAndOpen(
                      "/images/LegalType IT Security Specifications.pdf",
                      "IT_Security_Specs.pdf"
                    );
                  }}
                >
                  IT Security Specs
                </a>
              </li>
            </ul>

            {Quick_links.map(({ title, items }) => (
              <ul key={title} className="w-full ">
                <h6 className="mb-3 text-medium font-semibold text-black">
                  {title}
                </h6>
                {items.map((link) => (
                  <li key={link}>
                    <Link
                      href={link.link}
                      className="block py-1.5 text-sm font-normal text-black transition-colors hover:opacity-100"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            ))}

            {Reach_links.map(({ title, items }) => (
              <ul key={title} className="w-full">
                <h6 className="mb-3 text-medium font-semibold text-black">
                  {title}
                </h6>
                {items.map((link) => (
                  <li key={link}>
                    <Link href={link.link} target="_blank" className="block py-1.5">
                      <p className="text-sm font-semibold text-black">
                        {link.title}
                      </p>
                      <p className="text-sm font-normal">{link.value}</p>
                    </Link>
                  </li>
                ))}
              </ul>
            ))}
          </div>
        </div>

        {/* Social Media Icons */}
        <div className="flex justify-center md:justify-start gap-4 mt-6 md:mt-0">
          <Link href={"https://www.facebook.com/legaltype"} target="_blank">
            <FacebookIcon className="h-7 w-7" />
          </Link>
          <Link href={"https://youtube.com/@legaltype"} target="_blank">
            <YoutubeIcon className="h-7 w-7" />
          </Link>
          <Link href={"https://www.linkedin.com/showcase/legaltype"} target="_blank">
            <LinkeinIcon className="h-7 w-7" />
          </Link>
          <Link href={"https://instagram.com/getlegaltype"} target="_blank">
            <Image
              src={"/images/instagram.svg"}
              width="30"
              height="30"
              alt="instaIcon"
            />
          </Link>
        </div>
      </div>
    </footer>
  );
}
