
import { Button } from "@nextui-org/button";
import { Modal,ModalBody,ModalContent} from "@nextui-org/modal";
import { useRouter } from "next/navigation";

export default function SuccessModal({
  isOpen,
  onOpen,
  onOpenChange,
  onDone,
  title,
  desc,
}) {

    const router = useRouter();
  
  return (
    <>
      <Modal hideCloseButton isOpen={isOpen} onOpenChange={onOpenChange} placement="center">
        <ModalContent className="text-black py-6">
          {(onClose) => (
            <>
              <ModalBody>
                <div>
                    <div className="flex items-center justify-center">
                      <img
                        src="/images/Success.png"
                        alt="Alert Image"
                      />
                    </div>
                </div>
                <div className=" py-3 px-1 text-center">
                  <h3 className="text-xl font-semibold">{title}</h3>
                  <p className="text-gray-600 text-wrap font-lg py-4">{desc}</p>
                </div>
                <div className="flex justify-center gap-2">
                  <Button className="rounded-[2px] self-center bg-[#1BD1D8] text-black py-3 px-5 font-medium uppercase" onPress={()=>{
                    onOpenChange(false)
                    router.push('/license')
                }
                    }>
                    Go To License Key Page
                  </Button>
                </div>
              </ModalBody>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
}