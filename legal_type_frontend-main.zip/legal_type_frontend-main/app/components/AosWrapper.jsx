"use client";
import React, { useEffect } from "react";
import AOS from "aos";

function AosWrapper({ children }) {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  return children;
}

export default AosWrapper;
