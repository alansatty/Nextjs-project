// import { EyeFilledIcon, EyeSlashFilledIcon } from "@/app/assets/icon";
import { EyeFilledIcon } from "@/app/assets/icon/EyeFilledIcon";
import { EyeSlashFilledIcon } from "@/app/assets/icon/EyeSlashFilledIcon";
import { Input } from "@nextui-org/input";
import React from "react";


const FormInput = ({
  label,
  type,
  fieldName,
  required,
  errors,
  register,
  isVisible,
  toggleVisibility,
}) => {
  // Check if icons are defined before using them
  const endContent =
    type == "password" ? (
      <button
        className="focus:outline-none"
        type="button"
        onClick={toggleVisibility}
        aria-label="toggle password visibility"
      >
        {isVisible ? (
          <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
        ) : (
          <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
        )}
      </button>
    ) : '';

  return (
    <Input
      radius="sm"
      size="lg"
      className="mb-8"
      isRequired={required}
      type={isVisible && type === "password" ? "text" : type}
      label={label}
      variant="bordered"
      labelPlacement="outside"
      {...register(fieldName)}
      color={errors[fieldName] ? "danger" : ""}
      isInvalid={errors[fieldName]}
      errorMessage={errors[fieldName]?.message || ""}
      endContent={endContent}
    />
  );
};

export default FormInput;
