"use client";
import React, { useEffect, useState } from "react";
import {
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  NavbarMenuToggle,
  Button,
  NavbarMenuItem,
  NavbarMenu,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  DropdownTrigger,
  useDisclosure,
} from "@nextui-org/react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import NavbarSkeleton from "./NavbarSkeleton";
import AlertModal from "@/app/components/AlertModal";
import Avatar from "react-avatar";
import { useRouter } from "next/navigation";
import { Power } from "lucide-react";

function NavbarComponent() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [openAlert, setOpenAlert] = useState(false);
  const { isOpen, onOpen, onOpenChange } = useDisclosure();

  const { data: session, status } = useSession(); // Get session status

  const router = useRouter()

  useEffect(() => {
    if (session && session.user) {
      const { first_name, last_name, email } = session.user.data;
      setName(`${first_name} ${last_name}`);
      setEmail(email);
    }
  }, [session]);

  let pathName = usePathname();
  const menuItems = [
    { label: "Software", link: "/" },
    { label: "Subscription Plans", link: "/plans" },
    { label: "Manage License", link: "/license" },
    ,
    // { label: "About Us", link: "/about-us" },
    ...(!session ? [{ label: "Login", link: "/login" },
    { label: "Sign Up", link: "/signup" }] : []),
    ...(session ? [{ label: "Sign Out", link: "/" }] : [])
  ];

  // Render loading state if session is not available
  // if (!session) {
  //   return <NavbarSkeleton/>;
  // }

  return (
    <>
      <Navbar
        maxWidth="full"
        onMenuOpenChange={setIsMenuOpen}
        isMenuOpen={isMenuOpen}
        className="bg-white text-black"
        isBordered
      >
        <AlertModal
          isOpen={openAlert}
          onOpen={onOpen}
          onOpenChange={setOpenAlert}
          onDone={signOut}
          title={"Sign Out"}
          desc={"Are you sure you want to sign out?"}
        />

        <NavbarContent justify="start" className="ml-4">
          <NavbarMenuToggle
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            className="sm:hidden"
          />
          <NavbarBrand className="text-3xl font-bold">
            <Link href="/">
              <Image src="/images/logo.svg" alt="logo" height="200" width="200" />
            </Link>
          </NavbarBrand>
        </NavbarContent>

        <NavbarContent className="hidden sm:flex gap-4 " justify="end">
          <NavbarItem
            className="text-md font-medium text-black data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/"}
          >
            <Link color="foreground" href="/">
              SOFTWARE
            </Link>
          </NavbarItem>
          <NavbarItem
            className="text-md font-medium text-black data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/plans"}
          >
            <Link color="foreground" href="/plans">
              SUBSCRIPTION PLANS
            </Link>
          </NavbarItem>
          <NavbarItem
            className="text-md font-medium text-black data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/license"}
          >
            <Link href="/license" aria-current="page">
              MANAGE LICENSE
            </Link>
          </NavbarItem>


          {/* <NavbarItem
            className="text-md data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/about-us"}
          >
            <Link href="/about-us" aria-current="page">
              ABOUT US
            </Link>
          </NavbarItem> */}
        </NavbarContent>

        {session ? (
          <NavbarContent as="div" justify="center">
            <Dropdown placement="bottom-end">
              <DropdownTrigger>
                <div>
                  <div className="gap-3 cursor-pointer transition-transform hidden md:flex">
                    <Avatar
                      name={name}
                      size="40"
                      color="#1BD1D8"
                      fgColor="#000"
                      round
                      textSizeRatio={2}
                      className="" // Hide the avatar since we only need the data URL
                    />
                    <div className="flex flex-col">
                      <span className="text-small text-inherit">
                        {name.length > 20
                          ? `${name.substring(0, 20)}...`
                          : name}
                      </span>
                      <span className="text-tiny text-foreground-400">
                        {email.length > 50
                          ? `${email.substring(0, 50)}...`
                          : email}
                      </span>
                    </div>
                  </div>

                  <div className="md:hidden">
                    <Avatar
                      name={name}
                      size="40"
                      color="#1BD1D8"
                      fgColor="#000"
                      round
                      textSizeRatio={2}
                      className="bg-[#1BD1D8]" // Hide the avatar since we only need the data URL
                    />
                  </div>
                </div>
              </DropdownTrigger>

              <DropdownMenu
                aria-label="Profile Actions"
                className="text-black"
                variant="flat"
              >
                <DropdownItem key="settings" onClick={() => router.push('/profile')}>
                  Profile
                </DropdownItem>
                <DropdownItem key="team_settings" onClick={() => router.push('/paymenthistory')}>
                  Payment History
                </DropdownItem>
                <DropdownItem
                  key="logout"
                  onClick={() => setOpenAlert(true)}
                  color="danger"
                >
                  Sign Out
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </NavbarContent>
        ) : (
          <>
            <NavbarContent justify="center" className="hidden md:flex">
              <NavbarItem>
                <Link
                  href="/login"
                  className="relative inline-flex items-center justify-center overflow-hidden p-[2px] uppercase"
                >
                  <span className="absolute inset-0 bg-gradient-to-r from-[#1BD1D8] via-[#F06BDA] to-[#E2CBFF]"></span>
                  <span className="relative inline-flex items-center justify-center gap-2 bg-white px-6 py-[7px] text-md font-medium text-black backdrop-blur-md">
                    Login
                  </span>
                </Link>
              </NavbarItem>
              <NavbarItem>
                <Button
                  as={Link}
                  className="rounded-none uppercase bg-[#1BD1D8] text-md font-medium text-black"
                  href="/signup"
                  variant="light"
                >
                  Sign Up
                </Button>
              </NavbarItem>
            </NavbarContent>
            <NavbarContent justify="center" className="flex md:hidden">
              <NavbarItem>
                <Dropdown>
                  <DropdownTrigger>
                    <div

                      className="relative hidden cursor-pointer sm:inline-flex items-center justify-center overflow-hidden p-[2px] uppercase"
                    >
                      <span className="absolute inset-0 bg-gradient-to-r from-[#1BD1D8] via-[#F06BDA] to-[#E2CBFF]"></span>
                      <span className="relative inline-flex items-center justify-center gap-2 bg-white px-6 py-[7px] text-md font-medium text-black backdrop-blur-md">
                        <Power />
                      </span>
                    </div>
                  </DropdownTrigger>
                  <DropdownMenu aria-label="Auth Actions" className="text-black">
                    <DropdownItem key="signin"><Link href="/login">Login</Link></DropdownItem>
                    <DropdownItem key="signup"><Link href="/signup">Sign Up</Link></DropdownItem>
                  </DropdownMenu>
                </Dropdown>

              </NavbarItem>
            </NavbarContent>
          </>

        )}

        <NavbarMenu className="bg-white text-black">
          {menuItems.map((item, index) => (
            <NavbarMenuItem key={`${item.label}-${index}`}>
              {item.label === "Sign Out" ? (
                <Link
                  href={"/"}
                  onClick={() => setOpenAlert(true)}
                  color="danger"
                >
                  {item.label}
                </Link>
              ) : (
                <Link
                  className="w-full"
                  href={item.link}
                  onClick={() => {
                    setIsMenuOpen((prev) => !prev);
                  }}
                >
                  {item.label}
                </Link>
              )}
            </NavbarMenuItem>
          ))}
        </NavbarMenu>
      </Navbar>
    </>
  );
}

export default NavbarComponent;
