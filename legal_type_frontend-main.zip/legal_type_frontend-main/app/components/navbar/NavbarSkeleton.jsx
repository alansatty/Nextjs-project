"use client";
import {
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  NavbarMenuToggle,
  NavbarMenuItem,
  NavbarMenu,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  DropdownTrigger,
  User,
  Skeleton,
} from "@nextui-org/react";
import Link from "next/link";
import React from "react";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";

function NavbarSkeleton() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  let pathName = usePathname();
  const menuItems = [
    { label: "Software", link: "/" },
    { label: "Subscription Plans", link: "/plans" },
    { label: "License Key", link: "/license" },
    { label: "Log Out", link: "" },
  ];

  return (
    <>
      <Navbar
        maxWidth="full"
        onMenuOpenChange={setIsMenuOpen}
        isMenuOpen={isMenuOpen}
        className="bg-white text-black"
        isBordered
      >
        <NavbarContent justify="start" className="ml-4">
          <NavbarMenuToggle
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            className="sm:hidden"
          />
          <NavbarBrand className="text-3xl font-bold">
            <Link href="/">
              <Image src="/images/logo.svg" height="200" width="200" alt="logo" />
            </Link>
          </NavbarBrand>
        </NavbarContent>

        <NavbarContent className="hidden sm:flex gap-4 " justify="end">
          <NavbarItem
            className="text-md font-semibold data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/"}
          >
            <Link color="foreground" href="/">
              SOFTWARE
            </Link>
          </NavbarItem>
          <NavbarItem
            className="text-md font-semibold data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/plans"}
          >
            <Link color="foreground" href="/plans">
              SUBSCRIPTION PLANS
            </Link>
          </NavbarItem>
          <NavbarItem
            className="text-md font-semibold data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/license"}
          >
            <Link href="/license" aria-current="page">
              LICENSE KEY
            </Link>
          </NavbarItem>

          <NavbarItem
            className="text-md font-semibold data-[active=true]:text-[#1BD1D8]"
            isActive={pathName === "/about-us"}
          >
            <Link href="/about-us" aria-current="page">
              ABOUT US
            </Link>
          </NavbarItem>

        </NavbarContent>

    
          <NavbarContent as="div" justify="center">
            <Dropdown placement="bottom-end">
   
           
                <Skeleton className="rounded-lg">
                  <User
                    as="button"
                    className="transition-transform"
                    name="Loading..."
                    description="Please wait"
                    avatarProps={{
                      src: "https://i.pravatar.cc/150?u=a04258114e29026702d",
                    }}
                  />
                </Skeleton>
            
          
            </Dropdown>
          </NavbarContent>
       

        <NavbarMenu className="bg-white text-black">
          {menuItems.map((item, index) => (
            <NavbarMenuItem key={`${item.label}-${index}`}>
              {item.label === "Sign Out" ? (
                <Link
                  href={"/"}
                  key="logout"
                  onClick={() => setOpenAlert(true)}
                  color="danger"
                >
                  {item.label}
                </Link>
              ) : (
                <Link
                  color={
                    index === 2
                      ? "primary"
                      : index === menuItems.length - 1
                      ? "danger"
                      : "foreground"
                  }
                  className="w-full"
                  href={item.link}
                  size="lg"
                  onClick={() => {
                    // do something more here before closing...
                    setIsMenuOpen((prev) => !prev);
                    // do something more here after closing...
                  }}
                >
                  {item.label}
                </Link>
              )}
            </NavbarMenuItem>
          ))}
        </NavbarMenu>
      </Navbar>
    </>
  );
}

export default NavbarSkeleton;
