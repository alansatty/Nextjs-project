import React from "react";
import { Button } from "@nextui-org/react";

const PrimaryButton = ({ buttonText, className = "", onClick , ...props }) => {
  return (
    <Button
      className={`${className}`}
      size="lg"
      radius="full"
      type="submit"
      onClick={onClick}
      {...props}
    >
      {buttonText}
    </Button>
  );
};

export default PrimaryButton;
