"use client"
import React from "react";
import { Breadcrumbs, BreadcrumbItem } from "@nextui-org/react";
import { useRouter } from 'next/navigation';

export default function Breadcrumb({ prev, current, size = "lg", prevLink }) {
  const router = useRouter();

  const handlePrevClick = () => {
    if (prevLink) {
      router.push(prevLink);
    }
  };

  return (
    <Breadcrumbs size={size}>
      <BreadcrumbItem onClick={handlePrevClick} className="cursor-pointer text-blue-500">
        {prev}
      </BreadcrumbItem>
      <BreadcrumbItem className="text-black" isCurrent={true}>
        {current}
      </BreadcrumbItem>
    </Breadcrumbs>
  );
}
