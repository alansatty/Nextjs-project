import Image from "next/image";
import React from "react";

export const InstagramIcon = (props) => (
 <></>
)