import axios from "@/lib/axios";
import NextAuth from "next-auth/next";
import CredentialsProvider from "next-auth/providers/credentials";

async function login(credentials) {
  try {
   
    const formdata = new FormData()
    formdata.append('email_id' , credentials.email)
    formdata.append('password' , credentials.password)
    formdata.append('domain_url' , credentials.domain_url)
     
    const response = await axios.post(
        'api/login/password/app/',
         formdata
      );
         
      console.log("responce for login",response);

       if (response.status === 200) { 
 
        let {access_token , token_items} = response.data
        return {access_token , token_items}

       }
    
  } catch (error) {
     let errorMsg = error?.response?.data?.msg || "Something went wrong";
     throw new Error(errorMsg);
  }
}

export const authOptions = {
  pages: {
    signIn: "/login",
  },

  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {},
      async authorize(credentials, req) {
        try {
          const userData = await login(credentials);
          return userData;

        } catch (error) {
          console.log(error);
          throw new Error(error);
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {

      if (user) {
        token.token = user.access_token;
        token.userData = user.token_items
        }

      return token;
    },
    async session({ session, token }) {
    
      if (token) {
        session.user.token = token.token;
        session.user.data = token.userData;
      }
      


      return session;
    },
  },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };