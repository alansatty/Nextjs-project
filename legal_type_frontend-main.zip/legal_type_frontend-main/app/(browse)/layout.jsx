import  Footer from "../components/footer/page";
import NavbarComponent from "../components/navbar";

const BrowseLayout = ({ children }) => {
    return (
        <>
            <NavbarComponent/>
            <div>
                {children}
            </div>
            
            <Footer />
        </>
    );
};

export default BrowseLayout;