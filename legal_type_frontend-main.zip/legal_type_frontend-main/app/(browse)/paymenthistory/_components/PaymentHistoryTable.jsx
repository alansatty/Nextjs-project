"use client";
import React, { useEffect, useState } from "react";
import {
  Table,
  TableHeader,
  TableColumn,
  TableBody,
  TableRow,
  TableCell,
  Button,
  Chip,
  Pagination,
  DatePicker,
  DateRangePicker,
} from "@nextui-org/react";

import { columns } from "./data";
import { RotateCcw } from "lucide-react";
import { formatDateForTable, getPayments } from "@/lib/util";
import { useSession } from "next-auth/react";

const INITIAL_VISIBLE_COLUMNS = [
  "start_date",
  ,
  "key_id__key",
  "plan_id__plan_fee",
  "payment_method",
  "status",
];

export default function PaymentTable() {
  const [history, setHistory] = useState([]);
  const [totalPages, setTotalPages] = useState(null);
  const [totalItems, setTotalItems] = useState(null);
  const [purchaseDate, setPurchaseDate] = useState(null);
  const [selectedKeys, setSelectedKeys] = React.useState(new Set([]));
  const [isLoading, setIsLoading] = useState(false)
  const [visibleColumns, setVisibleColumns] = React.useState(
    new Set(INITIAL_VISIBLE_COLUMNS)
  );
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const [page, setPage] = React.useState(1);
  const { data: user } = useSession();

  useEffect(() => {
    if (user?.user) {
      getPaymentHistory();
    }
  }, [user, page, purchaseDate]);

  const resetFilters = () => {
    setPurchaseDate(null);
  };

  const pages = Math.ceil(history?.length / rowsPerPage);

  const getPaymentHistory = async () => {
    
    try {
      setIsLoading(true)
      const response = await getPayments(user?.user?.token, page, purchaseDate);
      setPage(response?.page);
      setTotalItems(response?.total_items);
      setTotalPages(response?.total_page);
      setHistory(response.data || []);
    } catch (error) {
      console.error("Failed to load history:", error);
    }finally {
      setIsLoading(false)
    }
  };

  const statusArray = [
    { label: "Free Trial", color: "info" },
    { label: "Pending", color: "warning" },
    { label: "Incomplete", color: "warning" },
    { label: "Failed", color: "danger" },
    { label: "Expired", color: "danger" },
    { label: "Cancelled", color: "danger" },
    { label: "Unpaid", color: "warning" },
    { label: "Active", color: "success" },
  ];

  const handlePurchaseDateChange = (data) => {
    setPurchaseDate(data);
    setPage(1);
  };
  const headerColumns = React.useMemo(() => {
    if (visibleColumns === "all") return columns;

    return columns.filter((column) =>
      Array.from(visibleColumns).includes(column.uid)
    );
  }, [visibleColumns]);

  const items = React.useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;

    return history;
  }, [page, history, rowsPerPage]);

  const renderCell = React.useCallback((license, columnKey, index) => {
    const cellValue = license[columnKey];

    switch (columnKey) {
      case "key_id__key":
        if (!cellValue) {
          return <div> N/A </div>;
        } else {
          return <div>{cellValue}</div>;
        }

      case "payment_method":
        return (
          <div>{license?.plan_id__plan_name == "Free" ? "Free" : "Stripe"}</div>
        );

      case "plan_id__plan_fee":
        return <div>${cellValue}</div>;

      case "status":
        // Adjust the cell value to use as index in the status array
        const statusInfo = statusArray[cellValue - 1] || {
          label: "Free Trial",
          color: "info",
        };
        return (
          <div className="flex flex-row">
            <Chip
              className="capitalize border-none gap-1 text-default-600"
              color={statusInfo.color}
              size="md"
              variant="dot"
            >
              {statusInfo.label}
            </Chip>
          </div>
        );

      case "start_date":
        if (!cellValue) {
          return <div>N/A</div>;
        }
        const date = new Date(cellValue);

        if (isNaN(date.getTime())) {
          return <div>Invalid Date</div>;
        }

        return <div>{formatDateForTable(date)}</div>;

      default:
        return cellValue;
    }
  }, []);

  const onRowsPerPageChange = React.useCallback((e) => {
    setRowsPerPage(Number(e.target.value));
    setPage(1);
  }, []);

  const topContent = React.useMemo(() => {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex justify-between gap-3 items-center flex-wrap">
          <h1 className="md:text-2xl text-large font-semibold">
            Payment History
          </h1>
          <div className="flex gap-3">
            <div className="flex gap-3">
              <DateRangePicker
                onChange={handlePurchaseDateChange}
                variant="bordered"
                label="Purchase date"
                value={purchaseDate}
                className="max-w-fit md:max-w-[284px]"
              />
            </div>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-default-400 text-small">
            Total {totalItems || 0} Payments
          </span>
          {purchaseDate && (
            <Button
              color="default"
              variant="flat"
              size="sm"
              radius="sm"
              onClick={resetFilters}
            >
              <RotateCcw size={18} />
              Reset Filters
            </Button>
          )}
        </div>
      </div>
    );
  }, [visibleColumns, onRowsPerPageChange, history.length, purchaseDate]);

  const bottomContent = React.useMemo(() => {
    return (
      totalItems > 10 && (
        <div className="py-2 px-2 flex justify-between text-black bg-white items-center">
          <Pagination
            isDisabled={isLoading}
            isCompact
            showControls
            showShadow
            color="primary"
            page={page}
            total={totalPages}
            onChange={setPage}
          />
        </div>
      )
    );
  }, [selectedKeys, items.length, page, pages, isLoading]);

  const classNames = React.useMemo(
    () => ({
      wrapper: ["max-h-[382px]", "bg-white"],
      th: ["bg-black", "text-md", "text-white"],
      td: ["bg-white", "text-md"],
      thead: "-top-[16px]"
    }),
    []
  );

  return (
    <div>
      <Table
        isHeaderSticky
        aria-label="Example table with custom cells, pagination and sorting"
        bottomContent={bottomContent}
        bottomContentPlacement="outside"
        checkboxesProps={{
          classNames: {
            wrapper:
              "max-h-[382px] w-full after:bg-white after: text-black bg-white text-black",
          },
        }}
        classNames={classNames}
        topContent={topContent}
        topContentPlacement="outside"
        onSelectionChange={setSelectedKeys}
      >
        <TableHeader columns={headerColumns}>
          {(column) => (
            <TableColumn
              key={column.uid}
              align={column.uid === "actions" ? "center" : "start"}
              allowsSorting={column.sortable}
            >
              {column.name}
            </TableColumn>
          )}
        </TableHeader>
        <TableBody emptyContent={"No History found"} items={items}>
          {items?.map((item, index) => (
            <TableRow key={item.id}>
              {(columnKey) => (
                <TableCell>{renderCell(item, columnKey, index)}</TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
