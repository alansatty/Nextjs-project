const columns = [
    {name: "PURCHASE DATE", uid: "start_date"},
    {name: "PURCHASE ITEM", uid: "key_id__key"},
    // {name: "PAYMENT METHOD", uid: "KeyType", sortable: true},
    {name:"PAYMENT METHOD", uid: "payment_method"},
    {name: "PAYMENT AMOUNT", uid: "plan_id__plan_fee"},
    {name: "STATUS", uid: "status"},

  ];
  
  const statusOptions = [
    {name: "Not Used", uid: "notUsed"},
    {name: "Expired", uid: "Expired"},
    {name: "Active", uid: "active"},
  ];
  
  const licenses = [
      {
        no: 1,
        LicenseKey: "ABC123456789",
        KeyType: "Full",
        PurchaseDate: "2023-01-15",
        ExpiryDate: "2024-01-15",
        status: "notUsed",
      },
      {
        no: 2,
        LicenseKey: "XYZ987654321",
        KeyType: "Trial",
        PurchaseDate: "2023-02-20",
        ExpiryDate: "2023-08-20",
        status: "active",
      },
      {
        no: 3,
        LicenseKey: "LMN456789012",
        KeyType: "Full",
        PurchaseDate: "2023-03-10",
        ExpiryDate: "2024-03-10",
        status: "Expired",
      },
      {
        no: 4,
        LicenseKey: "OPQ345678901",
        KeyType: "Subscription",
        PurchaseDate: "2023-04-05",
        ExpiryDate: "2024-04-05",
        status: "Expired",
      },
      {
        no: 5,
        LicenseKey: "RST234567890",
        KeyType: "Trial",
        PurchaseDate: "2023-05-12",
        ExpiryDate: "2023-11-12",
        status: "notUsed",
      },
      // Add more rows as needed
    ];
  
  export {columns, statusOptions};
  