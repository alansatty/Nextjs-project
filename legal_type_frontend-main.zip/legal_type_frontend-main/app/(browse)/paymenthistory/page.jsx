"use client"
import React from 'react'
import Breadcrumb from '@/app/components/breadcrumbs'
import PaymentHistoryTable from './_components/PaymentHistoryTable'

function PaymentHistory() {
    return (
        <div className='bg-gray-200 h-full '>
            <div className='pt-12 pl-12'>
                <Breadcrumb prev={"Software"} current={"Payment history"} prevLink={'/'}/>  </div>

            <div className='text-black mt-5 mb-5 md:mt-0  md:p-12 border  flex justify-center '>
                <div className='w-11/12 bg-white shadow-md  rounded-md p-4 md:p-6'>
                    <PaymentHistoryTable />
                </div>

            </div>
        </div>
    )
}

export default PaymentHistory