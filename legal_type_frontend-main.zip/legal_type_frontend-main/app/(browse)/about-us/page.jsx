"use client";
import Breadcrumb from "@/app/components/breadcrumbs";
import Aos from "aos";
import Image from "next/image";
import React, { useEffect } from "react";

const AboutPage = () => {
  useEffect(() => {
    Aos.init({ duration: 1000 });
  }, []);
  return (
    <>
      <div className="pt-12 pl-12 bg-white">
        <Breadcrumb prev={"Software"} current={"About Us"} prevLink={"/"} />{" "}
      </div>
      <section className="py-10 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800">
              About Us
            </h1>
          </div>

          <div data-aos="fade-right">
            {/* Founder Section */}
            <div className="flex flex-col md:flex-row items-center justify-center  md:items-start gap-12 mb-16">
              <div className="">
                <Image
                  src="/images/daniela.png"
                  alt="Daniela Semeco"
                  width={270}
                  height={270}
                  className="rounded-lg shadow-lg"
                  style={{ borderBottomRightRadius: "70px" }}
                />
              </div>
              <div className="w-full md:w-1/2">
                <h2 className="text-3xl font-bold text-gray-800 mb-4">
                  Daniela Semeco
                </h2>
                <p className="text-lg text-gray-600 mb-4">
                  Daniela Semeco is a Venezuelan-born inventor and entrepreneur
                  who developed a profound appreciation for the legal profession
                  after working with the Lawyers' Committee for Civil Rights.
                </p>
                <p className="text-lg text-gray-600">
                  Her experience with the Lawyers' Committee inspired her to
                  create LegalType, a tool that empowers lawyers to focus on
                  what truly matters—practicing law, not battling with their
                  keyboards.
                </p>
              </div>
            </div>
          </div>

          <div data-aos="fade-up">
            {/* Mission Section */}
            <div className="mb-16 md:mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">
                Our Mission
              </h2>
              <p className="text-lg text-center text-gray-600 mx-auto max-w-4xl">
                LegalType is the world’s first highly customizable keyboard
                designed specifically for lawyers, aimed at eliminating
                repetitive tasks and enhancing productivity and accuracy by 15%.
                Available as both a programmable mechanical keyboard and a
                digital download, LegalType accelerates and automates document
                creation, delivering significant time and cost savings.
              </p>
            </div>
          </div>

          <div data-aos="fade-right">
            {/* Co-Founder Section */}
            <div className="flex flex-col md:flex-row-reverse items-center justify-center md:items-start gap-12 mb-16">
              <div className="">
                <Image
                  src="/images/jacob.jpg"
                  alt="Jacob Alexander"
                  width={270}
                  height={270}
                  className="rounded-lg shadow-lg"
                  style={{ borderBottomLeftRadius: "70px" }}
                />
              </div>
              <div className="w-full md:w-1/2">
                <h2 className="text-3xl font-bold text-gray-800 mb-4">
                  Jacob Alexander
                </h2>
                <p className="text-lg text-gray-600 mb-4">
                  Jacob Alexander, one of the world’s leading experts in
                  keyboard technology and the inventor of the Halo and Silo
                  mechanical keyboard switches, teamed up with his co-founder
                  and wife, Daniela Semeco, to bring LegalType to life.
                </p>
              </div>
            </div>
          </div>

          {/* Call to Action Section */}
          <div className="text-center mb-12">
            <p className="text-xl text-gray-600 mb-4">
              Discover more about how LegalType can transform your legal
              practice at{" "}
              <a
                href="https://www.legaltype.com"
                className="text-blue-600 hover:underline"
              >
                www.legaltype.com
              </a>
              .
            </p>
          </div>

          <div data-aos="fade-up">
            {/* Contact Section */}
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                Contact Us
              </h2>
              <p className="text-lg text-gray-600 mb-2">
                Got questions? Reach out at{" "}
                <a
                  href="mailto:info@legaltype.com"
                  className="text-blue-600 hover:underline"
                >
                  info@legaltype.com
                </a>{" "}
                —we're just an email away!
              </p>
              <p className="text-lg text-gray-600">
                Address:
                <br />
                LegalType
                <br />
                1043 Garland Ave, Unit C #1272
                <br />
                San Jose, CA 95126
                <br />
                USA
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;
