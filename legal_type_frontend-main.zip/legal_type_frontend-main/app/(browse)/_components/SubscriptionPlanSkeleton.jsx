import React from 'react';
import { Skeleton } from '@nextui-org/react';

export default function SubscriptionPlansSkeleton() {
  const skeletonItems = [1, 2]; // Adjust the number of skeletons to match the expected number of cards

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 text-center">
        <Skeleton className="h-6 w-24 mb-2 mx-auto rounded-md" />
        <Skeleton className="h-10 w-48 mb-8 mx-auto rounded-md" />
        
        <div className="flex flex-col md:flex-row justify-center items-stretch gap-8">
          {skeletonItems.map((item, index) => (
            <div key={index} className="w-full md:w-1/4 flex flex-col text-white rounded-lg overflow-hidden border-1 shadow-sm">
              <div className="py-6 px-4 bg-[#5A137C]">
                <Skeleton className="h-6 w-full rounded-md" />
              </div>
              <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col justify-between">
                <ul className="text-left space-y-2">
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                  <li>
                    <Skeleton className="h-4 w-full rounded-md" />
                  </li>
                </ul>
                <Skeleton className="h-10 w-full mt-6 mb-3" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
