import { Skeleton } from '@nextui-org/react'
import React from 'react'

function SubscriptionPlanLoader() {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 px-2 md:px-10 justify-center">
            <div
                className="flex flex-col text-white rounded-lg overflow-hidden border shadow-sm animate-pulse"
            >
                <div className="py-6 px-4 bg-slate-50 text-xl font-semibold">
                </div>
                <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col gap-4 justify-between">
                    <Skeleton className=' rounded h-5 w-5/6' />
                    <Skeleton className='rounded h-5 w-2/4' />
                    <Skeleton className='rounded w-3/4 h-5' />
                    <Skeleton className='w-full rounded h-5' />
                </div>
            </div>
            <div
                className="flex flex-col text-white rounded-lg overflow-hidden border shadow-sm animate-pulse"
            >
                <div className="py-6 px-4 bg-slate-50 text-xl font-semibold">
                </div>
                <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col gap-4 justify-between">
                    <Skeleton className=' rounded h-5 w-5/6' />
                    <Skeleton className='rounded h-5 w-2/4' />
                    <Skeleton className='rounded w-3/4 h-5' />
                    <Skeleton className='w-full rounded h-5' />
                </div>
            </div>
            <div
                className="flex flex-col text-white rounded-lg overflow-hidden border shadow-sm animate-pulse"
            >
                <div className="py-6 px-4 bg-slate-50 text-xl font-semibold">
                </div>
                <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col gap-4 justify-between">
                    <Skeleton className=' rounded h-5 w-5/6' />
                    <Skeleton className='rounded h-5 w-2/4' />
                    <Skeleton className='rounded w-3/4 h-5' />
                    <Skeleton className='w-full rounded h-5' />
                </div>
            </div>

        </div>
    )
}

export default SubscriptionPlanLoader