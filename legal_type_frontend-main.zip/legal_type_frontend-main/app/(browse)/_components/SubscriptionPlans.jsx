"use client";
import React, { useEffect, useState } from "react";
import { CheckCircle } from "lucide-react";
import axios from "@/lib/axios";
import PrimaryButton from "@/app/components/button";
import { useRouter } from "next/navigation";
import SubscriptionPlansSkeleton from "./SubscriptionPlanSkeleton";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { Button, Skeleton } from "@nextui-org/react";
import SuccessModal from "@/app/components/SuccessModal";
import SubscriptionPlanLoader from "./SubscriptionPlanLoader";

export default function SubscriptionPlans() {
  const { data: user } = useSession();
  const [monthly, setMonthly] = useState([]);
  const [yearly, setYearly] = useState([]);
  const [oneTimePlan, setOneTimePlan] = useState([]);
  const [freePlan, setFreePlan] = useState([]);
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [isSuccess, setIsSuccess] = useState(false);
  const [loadingState, setLoadingState] = useState({}); // Track loading state for each plan
  const token = user?.user?.token;
  const [message, setMessage] = useState("")


  const goToPaymentFreePlan = async (id) => {
    if (id) {
      setLoadingState((prev) => ({ ...prev, [id]: true })); // Set loading for specific plan

      if (!token) {
        router.push("/login");
      }

      try {
        let formData = new FormData();

        formData.append(
          "success_url",
          `${process.env.NEXT_PUBLIC_DOMAIN_URL}payment-success`
        );
        formData.append(
          "cancel_url",
          `${process.env.NEXT_PUBLIC_DOMAIN_URL}payment-error`
        );

        let response = await axios.post(`/api/link/${id}/`, formData);


        if (response.status === 200) {
          setMessage(response.data.msg);
          setIsSuccess(true);
          // router.push(response?.data?.url);
        }
      } catch (error) {
        console.log(error);
      } finally {
        setLoadingState((prev) => ({ ...prev, [id]: false })); // Clear loading for specific plan
      }
    }

  }

  const goToPayment = async (id) => {
    if (id) {
      setLoadingState((prev) => ({ ...prev, [id]: true })); // Set loading for specific plan

      if (!token) {
        router.push("/login");
      }

      try {
        let formData = new FormData();

        formData.append(
          "success_url",
          `${process.env.NEXT_PUBLIC_DOMAIN_URL}payment-success`
        );
        formData.append(
          "cancel_url",
          `${process.env.NEXT_PUBLIC_DOMAIN_URL}payment-error`
        );

        let response = await axios.post(`/api/link/${id}/`, formData);

        if (response.status === 200) {
          router.push(response?.data?.url);
        }
      } catch (error) {
        console.log(error);
      } finally {
        setLoadingState((prev) => ({ ...prev, [id]: false })); // Clear loading for specific plan
      }
    }
  };

  useEffect(() => {
    axios
      .get("/api/subscription_list/")
      .then((response) => {
        const { monthly_plan, one_time_plan, free_plan } = response.data;
        console.log(monthly_plan, one_time_plan, free_plan, "plans");
        setMonthly(monthly_plan);
        setOneTimePlan(one_time_plan);
        setFreePlan(free_plan)
      })
      .catch((error) => {
        console.error("Error fetching subscription plans:", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <section className="py-16 bg-white">
      <SuccessModal isOpen={isSuccess} onOpenChange={setIsSuccess} title={message} desc={""} />
      <div className="container mx-auto px-4 text-center">
        <h5 className="text-[#1BD1D8] text-medium font-semibold uppercase  mb-2">
          LegalType
        </h5>
        <h2 className="text-3xl md:text-4xl font-bold text-black mb-8">
          Digital Downloads
        </h2>
        {
          loading && (
            < SubscriptionPlanLoader />
          )
        }
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 px-2 md:px-10 justify-center">
          {freePlan?.map((plan) => (
            <div
              key={plan.id}
              className="flex flex-col text-white rounded-lg overflow-hidden border shadow-sm"
            >
              <div className="py-6 px-4 bg-black text-xl font-semibold">
                {plan.plan_name} Trial
              </div>
              <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col justify-between">
                <ul className="text-left space-y-3 mb-5">
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] mr-2 flex-shrink-0" />
                    No credit card required.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] mr-2 flex-shrink-0" />
                    Enjoy full access to all of our features for one month.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] mr-2 flex-shrink-0" />
                    One license per computer.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] mr-2 flex-shrink-0" />
                    Upgrade when you're ready!
                  </li>
                </ul>
                <button
                  onClick={() => goToPaymentFreePlan(plan.id)}
                  className="mt-6 rounded-[2px] self-center bg-[#1BD1D8] text-black py-3 px-5 font-medium uppercase"
                >
                  DOWNLOAD NOW
                </button>
              </div>
            </div>
          ))}

          {monthly?.map((plan) => (
            <div
              key={plan.id}
              className="flex flex-col text-white rounded-lg overflow-hidden border shadow-sm"
            >
              <div className="py-6 px-4 bg-black text-xl font-semibold">
                {plan.plan_name} (${plan.plan_fee})
              </div>
              <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col justify-between">
                <ul className="text-left space-y-3 mb-5">
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Automatic recurring payments.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Enjoy full access to all of our features.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    One license per computer.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Cancel at any time.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    24/7 VIP customer service
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Custom solutions available for enterprise clients.
                  </li>
                </ul>
                <button
                  onClick={() => goToPayment(plan.id)}
                  className="mt-6 rounded-[2px] self-center bg-[#1BD1D8] text-black py-3 px-5 font-medium uppercase"
                >
                  DOWNLOAD NOW
                </button>
              </div>
            </div>
          ))}

          {oneTimePlan?.map((plan) => (
            <div
              key={plan.id}
              className="flex flex-col text-white rounded-lg overflow-hidden border shadow-sm"
            >
              <div className="py-6 px-4 bg-black text-xl font-semibold">
                {plan.plan_name} (${plan.plan_fee})
              </div>
              <div className="flex-grow bg-white text-black py-6 px-4 flex flex-col justify-between">
                <ul className="text-left space-y-3 mb-5">
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    One time payment.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Enjoy full access to all of our features.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    One license per computer.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Upgrade to the latest version for only $20.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    VIP customer service: first 10 phone calls free, then $10 per customer inquiry.
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-[#1BD1D8] w-5 h-5 mr-2 flex-shrink-0" />
                    Custom solutions available for enterprise clients.
                  </li>
                </ul>
                <button
                  onClick={() => goToPayment(plan.id)}
                  className="mt-6 rounded-[2px] self-center bg-[#1BD1D8] text-black py-3 px-5 font-medium uppercase"
                >
                  DOWNLOAD NOW
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
