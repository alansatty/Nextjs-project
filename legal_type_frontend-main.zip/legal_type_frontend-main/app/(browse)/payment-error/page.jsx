import Link from 'next/link'
import React from 'react'

const Page = () => {
  return (
    <div className="bg-gray-100 h-full">
      <div className="bg-white p-6 md:mx-auto">
        {/* Cross mark icon */}
        <svg viewBox="0 0 24 24" className="text-red-600 w-16 h-16 mx-auto my-6">
          <path fill="currentColor" d="M12,0A12,12,0,1,0,24,12,12.014,12.014,0,0,0,12,0ZM16.971,7.029a1,1,0,0,1,0,1.414L13.414,12l3.557,3.557a1,1,0,0,1-1.414,1.414L12,13.414l-3.557,3.557a1,1,0,1,1-1.414-1.414L10.586,12,7.029,8.443a1,1,0,1,1,1.414-1.414L12,10.586l3.557-3.557A1,1,0,0,1,16.971,7.029Z"/>
        </svg>

        <div className="text-center">
          <h3 className="md:text-2xl text-base text-gray-900 font-semibold text-center">Payment Cancelled</h3>
          <p className="text-gray-600 my-2">Unfortunately, your payment was not successful.</p>
          <p>If you have any questions, please contact our support team.</p>
          <div className="py-10 text-center">
            <Link href="/license" className="px-12 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3">
               View License Keys
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Page;
