import React from "react";
import {
  Modal,
  ModalContent,
  ModalBody,
  Button,
  Tooltip
} from "@nextui-org/react";

export default function MachineDetailModal({
  isOpen,
  onOpenChange,
  machineDetail,  // Prop to accept machine details
  onCloseModal,  // Close modal handler
}) {
  return (
    <Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="center">
  <ModalContent className="bg-white text-black rounded-xl shadow-2xl w-full max-w-lg p-6">
    <ModalBody>
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Machine Details</h2>
        <p className="text-sm text-gray-500 mt-2">
          Detailed information for the selected machine.
        </p>
      </div>

      {machineDetail ? (
        <div className="divide-y divide-gray-200 border border-gray-300 rounded-lg overflow-hidden">
        {Object.entries(machineDetail).map(([key, value], index) => {
          const displayValue =
            value === null || value === undefined || value === "" ? "-" : String(value);
      
          return (
            <div
              key={key}
              className={`flex items-start sm:items-center gap-2 sm:gap-4 px-4 py-3 ${
                index % 2 === 0 ? "bg-gray-50" : "bg-white"
              }`}
            >
              <div className="min-w-[160px] max-w-[200px] font-semibold text-gray-700 capitalize">
                {key.replace(/_/g, " ")}
              </div>
      
              <Tooltip
                content={displayValue}
                delay={300}
                placement="top-start"
                className="z-50 px-2 py-1 bg-black text-white text-sm rounded"
              >
                <div className="text-gray-900 max-w-[250px] truncate break-all cursor-help">
                  {displayValue}
                </div>
              </Tooltip>
            </div>
          );
        })}
      </div>
      
      ) : (
        <p className="text-center text-sm text-gray-500">No machine details available.</p>
      )}

      <div className="mt-8 flex justify-center">
        <Button
          className="bg-black text-white font-semibold text-sm px-6 py-2 rounded-md hover:bg-gray-800 transition"
          onPress={onCloseModal}
        >
          Close
        </Button>
      </div>
    </ModalBody>
  </ModalContent>
</Modal>
  );
}
