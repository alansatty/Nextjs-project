const columns = [
  {name: "S. NO", uid: "no"},
  {name: "LICENSE KEY", uid: "key_id__key"},
  {name: "KEY TYPE", uid: "is_free_trial"},
  {name: "PURCHASE DATE", uid: "start_date"},
  {name: "EXPIRY DATE", uid: "end_date"},
  {name: "KEY STATUS", uid: "key_used"},
  {name: "STATUS", uid: "status"},
  {name: "", uid: "action"},
];

const statusOptions = [
  { uid: "all", name: "All" },
  // { uid: 1, name: "Free Trial" },
  // { uid: 2, name: "Pending" }, 
  // { uid: 3, name: "Incomplete" }, 
  // { uid: 4, name: "Failed" }, 
  { uid: 5, name: "Expired" }, 
  { uid: 6, name: "Cancelled" },
  // { uid: 7, name: "Unpaid" },
  { uid: 8, name: "Active" },
];

const licenses = [
    {
      no: 1,
      LicenseKey: "ABC123456789",
      KeyType: "Full",
      PurchaseDate: "2023-01-15",
      ExpiryDate: "2024-01-15",
      status: "notUsed",
    },
    {
      no: 2,
      LicenseKey: "XYZ987654321",
      KeyType: "Trial",
      PurchaseDate: "2023-02-20",
      ExpiryDate: "2023-08-20",
      status: "active",
    },
    {
      no: 3,
      LicenseKey: "LMN456789012",
      KeyType: "Full",
      PurchaseDate: "2023-03-10",
      ExpiryDate: "2024-03-10",
      status: "Expired",
    },
    {
      no: 4,
      LicenseKey: "OPQ345678901",
      KeyType: "Subscription",
      PurchaseDate: "2023-04-05",
      ExpiryDate: "2024-04-05",
      status: "Expired",
    },
    {
      no: 5,
      LicenseKey: "RST234567890",
      KeyType: "Trial",
      PurchaseDate: "2023-05-12",
      ExpiryDate: "2023-11-12",
      status: "notUsed",
    },
    {
      no: 5,
      LicenseKey: "RST234567890",
      KeyType: "Trial",
      PurchaseDate: "2023-05-12",
      ExpiryDate: "2023-11-12",
      status: "notUsed",
    },
    {
      no: 5,
      LicenseKey: "RST234567890",
      KeyType: "Trial",
      PurchaseDate: "2023-05-12",
      ExpiryDate: "2023-11-12",
      status: "notUsed",
    },
    {
      no: 5,
      LicenseKey: "RST234567890",
      KeyType: "Trial",
      PurchaseDate: "2023-05-12",
      ExpiryDate: "2023-11-12",
      status: "notUsed",
    },
    {
      no: 5,
      LicenseKey: "RST234567890",
      KeyType: "Trial",
      PurchaseDate: "2023-05-12",
      ExpiryDate: "2023-11-12",
      status: "notUsed",
    },
    {
      no: 5,
      LicenseKey: "RST234567890",
      KeyType: "Trial",
      PurchaseDate: "2023-05-12",
      ExpiryDate: "2023-11-12",
      status: "notUsed",
    },
    // Add more rows as needed
  ];

export {columns,statusOptions};
