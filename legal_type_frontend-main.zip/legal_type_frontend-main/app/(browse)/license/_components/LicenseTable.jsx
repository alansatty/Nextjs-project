"use client";
import React, { useEffect, useMemo, useState } from "react";
import {
  Table,
  TableHeader,
  TableColumn,
  TableBody,
  TableRow,
  TableCell,
  Button,
  DropdownTrigger,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Chip,
  Pagination,
  DatePicker,
  Snippet,
  useDisclosure,
  Select,
  SelectItem,
  DateRangePicker,
} from "@nextui-org/react";

import { columns, statusOptions } from "./data";
import { EllipsisVertical, PlusIcon, RotateCcw } from "lucide-react";
import { formatDateForTable, getLicenses } from "@/lib/util";
import AlerModal from "../../../components/AlertModal";
import MachineDetailModal from "./MachineDetailModal"; 
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import axios from "@/lib/axios";
import toast from "react-hot-toast";
import Link from "next/link";

const statusArray = [
  { key: 5, label: "Expired", color: "danger" },
  { key: 6, label: "Cancelled", color: "danger" },
  { key: 8, label: "Active", color: "success" },
];

const INITIAL_VISIBLE_COLUMNS = [
  "no",
  "key_id__key",
  "is_free_trial",
  "start_date",
  "end_date",
  "key_used",
  "status",
  "action",
];

// isDisabled={
//   license.status == 5 ||
//   license.status == 6 ||
//   license.status < 2 ||
//   license?.plan_id__plan_name == "Free" ||
//   license?.plan_id__plan_name == "One Time"
// }

export default function LicenseTable() {
  const { onOpen } = useDisclosure();
  const [licenses, setLicenses] = useState([]);
  const [totalPages, setTotalPages] = useState(null);
  const [totalItems, setTotalItems] = useState(null);
  const [selectedKeys, setSelectedKeys] = React.useState(new Set([]));
  const [visibleColumns, setVisibleColumns] = React.useState(
    new Set(INITIAL_VISIBLE_COLUMNS)
  );
  const [selectedId, setSelectedId] = useState("");
  const [resetKey, setResetKey] = useState(0);
  const [dateType, setDateType] = useState(null);
  const [dateRange, setDateRange] = useState(null);

  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [openAlert, setOpenAlert] = useState(false);
  const { data: user } = useSession();
  const router = useRouter();
  const [page, setPage] = React.useState(1);
  const [isLoading, setIsLoading] = useState(false)
  const [StatusValue, setStatusValue] = React.useState("all");
  const [openMachineModal, setOpenMachineModal] = useState(false);
  const [selectedMachineDetail, setSelectedMachineDetail] = useState(null);
  

  useEffect(() => {
    if (user?.user) {
      getLicenseData();
    }
  }, [user, page, StatusValue, dateRange, dateType]);

  const pages = Math.ceil(licenses?.length / rowsPerPage);

  const getLicenseData = async () => {
    
    try {
      setIsLoading(true)
      const response = await getLicenses(
        user?.user?.token,
        page,
        dateRange,
        dateType,
        StatusValue
      );

      setPage((prevPage) =>
        response.page !== prevPage ? response.page : prevPage
      );
      setTotalItems(response?.total_items);
      setTotalPages(response?.total_page);

      setLicenses(response.data);
    } catch (error) {
      console.error("Failed to load licenses:", error);
    }finally {
      setIsLoading(false)
    }
  };

  const downloadLink = (url) => {
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', true); // Optional: Forces download behavior
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const CancelSubscription = async () => {
    if (selectedId) {
      try {
        const response = await axios.post(`api/plans/cancel/${selectedId}/`);

        toast.success("License Cancelled");
        setOpenAlert(false);

        getLicenseData();
      } catch (error) {
        console.log(error);
      }
    }
  };



  const headerColumns = React.useMemo(() => {
    if (visibleColumns === "all") return columns;

    return columns.filter((column) =>
      Array.from(visibleColumns).includes(column.uid)
    );
  }, [visibleColumns]);

  const items = React.useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;

    return licenses;
  }, [page, licenses, rowsPerPage]);

  const resetFilters = () => {
    setDateRange(null);
    setDateType(null);
    setStatusValue("all");
    setResetKey(prevKey => prevKey + 1);
  };

  const renderCell = React.useCallback(
    (license, columnKey, index) => {
      const cellValue = license[columnKey];

      switch (columnKey) {
        case "key_id__key":
          if (!cellValue) {
            return <div> N/A </div>;
          } else {
            return (
              <div>
                <Snippet
                  symbol=""
                  className="text-black"
                  tooltipProps={{ color: "primary" }}
                  variant="flat"
                >
                  {cellValue}
                </Snippet>
              </div>
            );
          }

        case "no":
          const correctIndex = (page - 1) * 10 + (index + 1);
          return <div>{correctIndex}</div>;

        case "key_used":
          return cellValue ? <div>Used</div> : <div>Not Used</div>;

        case "status":
          // Adjust the cell value to use as index in the status array
          const statusInfo = statusArray.find(
            (status) => status.key === cellValue
          );

          return (
            <div className="flex flex-row">
              <Chip
                className="capitalize border-none  gap-1 text-default-600"
                color={statusInfo?.color}
                size="md"
                variant="dot"
              >
                {statusInfo?.label}
              </Chip>
            </div>
          );

        case "action":
          return (
          
             <div className="relative flex justify-center items-center gap-2">
              
             <div className="relative flex justify-between items-center gap-2">
            
             <Link href={`/license/${license.id}`}>
         <button className="px-3 py-1.5 text-small rounded-medium bg-[#1BD1D8] text-black"  >Details</button>
        </Link>
             <Dropdown className="bg-white text-black border-1 border-default-200">
               <DropdownTrigger>
                 <Button
               
                   isIconOnly
                   radius="full"
                   size="sm"
                   variant="light"
                 >
                   <EllipsisVertical className="text-default-400" />
                 </Button>
               </DropdownTrigger>
               <DropdownMenu>
               {(license.status !== 5 && 
                 license.status !== 6 && 
                 license.status >= 2 && 
                 license?.plan_id__plan_name !== "Free" && 
                 license?.plan_id__plan_name !== "One Time") && (
                   <DropdownItem
                     onClick={() => {
                       setOpenAlert(true);
                       setSelectedId(license.id);
                     }}
                   >
                     Cancel Subscription
                   </DropdownItem>
               )}

                   <DropdownItem
                   onClick={()=>downloadLink("https://zaigocommon.s3.us-east-2.amazonaws.com/LegalType_wL8xziY.msi")}
                   >
                    Download msi file
                   </DropdownItem>
                   <DropdownItem
                   onClick={()=>downloadLink("https://zaigocommon.s3.us-east-2.amazonaws.com/LegalType.exe")}
                   >
                    Download exe file
                   </DropdownItem>
                   <DropdownItem
                       onClick={() => {
                         setSelectedMachineDetail(license.machine_detail);
                         setOpenMachineModal(true);
                       }}
                   >
                   Machine Details
                   </DropdownItem>


               </DropdownMenu>
             </Dropdown>
           </div>
             </div>

      
           
          );

        case "is_free_trial":
          return <div>{license?.plan_id__plan_name || "N/A"}</div>;

        case "start_date":
          if (!cellValue) {
            return <div>N/A</div>;
          }
          const date = new Date(cellValue);

          if (isNaN(date.getTime())) {
            return <div>Invalid Date</div>;
          }
          return <div>{formatDateForTable(date)}</div>;

        case "end_date":
          if (!cellValue) {
            return <div>N/A</div>;
          }
          const endDate = new Date(cellValue);

          if (isNaN(endDate.getTime())) {
            return <div>Invalid Date</div>;
          }
          return <div>{formatDateForTable(endDate)}</div>;

        default:
          return cellValue;
      }
    },
    [page, dateType]
  );

  const onRowsPerPageChange = React.useCallback((e) => {
    setRowsPerPage(Number(e.target.value));
    setPage(1);
  }, []);

  const topContent = useMemo(() => {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex justify-between gap-3 items-end flex-wrap lg:flex-nowrap">
          <h1 className="md:text-2xl text-large font-semibold">
            Purchased License Key
          </h1>
          <div className="flex gap-3 w-full lg:max-w-fit flex-wrap lg:flex-nowrap items-end justify-between">
            
            <Select
              key={resetKey}
              value={dateType || null}
              onSelectionChange={(val) => {
                setDateType(val.currentKey);
                setDateRange(null)
                setPage(1)
              }}
              label="Date Type"
              className="w-full md:w-40 text-black"
            >
              <SelectItem className="text-black " key={"Purchase"}>
                Purchase Date
              </SelectItem>
              <SelectItem className="text-black " key={"Expiry"}>
                Expiry Date
              </SelectItem>
            </Select>

            {dateType && (
              <DateRangePicker
                onChange={(val) => {
                  setDateRange(val);
                  setPage(1)
                }}
                variant="bordered"
                value={dateRange}
                label={dateType + " Date"}
                className="max-w-full md:max-w-[284px]"
              />
            )}

            <Select
              showScrollIndicators={true}
              label="Status"
              className="w-1/2 md:w-40 text-black"
              onChange={(e) => {
                setStatusValue(e.target.value)
                setPage(1)
              }}
              value={StatusValue}
              selectedKeys={[StatusValue]}
              defaultSelectedKeys={["all"]}
            >
              {statusOptions.map((status) => (
                <SelectItem className="text-black " key={status.uid}>
                  {status.name}
                </SelectItem>
              ))}
            </Select>

            <Button
              className="bg-[#1BD1D8] text-black font-medium py-6 "
              startContent={<PlusIcon />}
              size="md"
              onClick={() => router.push("/plans")}
            >
              Buy New
            </Button>
          </div>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-default-400 text-small">
            Total {totalItems || 0} License
          </span>
          {(dateType || dateRange || StatusValue !== "all") && (
            <Button
              color="default"
              variant="flat"
              size="sm"
              radius="sm"
              onClick={resetFilters}
            >
              <RotateCcw size={18} />
              Reset Filters
            </Button>
          )}
        </div>
      </div>
    );
  }, [
    visibleColumns,
    onRowsPerPageChange,
    licenses.length,
    StatusValue,
    dateType,
    resetKey,
    setDateType,
    dateRange,
    resetFilters,
  ]);

  const bottomContent = React.useMemo(() => {
    return (
      totalItems > 10 && (
        <div className="py-2 px-2 flex justify-between text-black bg-white items-center">
          <Pagination
            isDisabled={isLoading}
            isCompact
            showControls
            showShadow
            color="primary"
            page={page}
            total={totalPages}
            onChange={setPage}
          />
        </div>
      )
    );
  }, [selectedKeys, items.length, page, pages,isLoading]);

  const classNames = React.useMemo(
    () => ({
      wrapper: ["max-h-[382px]" , "bg-white"],
       thead: "-top-[16px]",
      th: ["bg-black", "text-md", "text-white", "rounded-none"],
      td: [
        "bg-white",
        "text-md",
        "group-data-[first=true]:first:before:rounded-none",
        "group-data-[first=true]:last:before:rounded-none",
        "group-data-[middle=true]:before:rounded-none",
        "group-data-[last=true]:first:before:rounded-none",
        "group-data-[last=true]:last:before:rounded-none",
      ],
    }),
    []
  );

  return (
    <div>
      <AlerModal
        isOpen={openAlert}
        onOpen={onOpen}
        onOpenChange={setOpenAlert}
        onDone={CancelSubscription}
        title={"Cancel Subscription"}
        desc={"Are you sure you want to cancel your subscription?"}
      />
      <MachineDetailModal
        isOpen={openMachineModal}
        onOpenChange={setOpenMachineModal}
        machineDetail={selectedMachineDetail}
        onCloseModal={() => setOpenMachineModal(false)}
      />
      <Table
        // removeWrapper
        isHeaderSticky
        aria-label="License table"
        bottomContent={bottomContent}
        bottomContentPlacement="outside"
        classNames={classNames}
        topContent={topContent}
        topContentPlacement="outside"
        onSelectionChange={setSelectedKeys}
      >
        <TableHeader columns={headerColumns}>
          {(column) => (
            <TableColumn
              key={column.uid}
              align={column.uid === "actions" ? "center" : "start"}
              allowsSorting={column.sortable}
            >
              {column.name}
            </TableColumn>
          )}
        </TableHeader>
        <TableBody emptyContent={"No history found"} items={items}>
          {items?.map((item, index) => (
            <TableRow key={item.id}>
              {(columnKey) => (
                <TableCell>{renderCell(item, columnKey, index)}</TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
