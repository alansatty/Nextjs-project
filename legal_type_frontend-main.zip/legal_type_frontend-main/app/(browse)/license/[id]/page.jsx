"use client";
import Breadcrumb from "@/app/components/breadcrumbs";
import axios from "@/lib/axios";
import { useSession } from "next-auth/react";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import {
  FaCcVisa,
  FaCcMastercard,
  FaCcAmex,
  FaCcDiscover,
} from "react-icons/fa";
import { SiRupay } from "react-icons/si";
import {
  CreditCard,
  Package,
  FileText,
  Receipt,
  Calendar,
  MapPin,
  Mail,
  Phone,
  Hash,
  CheckCircle,
  Clock,
} from "lucide-react";
import { Card, CardHeader, useDisclosure } from "@nextui-org/react";
import CardDetailsPopup from "./_components/popupPayment";

// Custom Card components
// Custom Badge component
const Badge = ({ children, variant = "default", className = "" }) => {
  const baseClasses =
    "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium";
  const variants = {
    default: "bg-blue-100 text-blue-800",
    secondary: "bg-gray-100 text-gray-800",
    outline: "border border-gray-300 text-gray-700 bg-white",
  };
  return (
    <span className={`${baseClasses} ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
};

const CardTitle = ({ children, className = "" }) => (
  <h3
    className={`text-lg font-semibold leading-none tracking-tight ${className}`}
  >
    {children}
  </h3>
);

const CardContent = ({ children, className = "" }) => (
  <div className={`px-6 pb-6 ${className}`}>{children}</div>
);

// Custom Separator component
const Separator = ({ className = "" }) => (
  <hr className={`border-gray-200 ${className}`} />
);

export default function ViewLicense() {
  const { data: user } = useSession();
  const token = user?.user?.token;
  const { id } = useParams();
  const [subscription, setSubscription] = useState(null);
  const [plan, setPlan] = useState(null);
  const [billing, setBilling] = useState(null);
  const [payment, setPayment] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const { isOpen, onOpenChange } = useDisclosure();
  const [isLoading,setLoading] = useState(true);

  useEffect(() => {
    licenseDetails();
    return () => {};
  }, [id]);

  const licenseDetails = async () => {
    try {
      const response = await axios.get(`/api/license/key/subscription/${id}/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const { subscription, plan, payment_method_details } = response.data;
      setSubscription(subscription);
      setPlan(plan);
      setBilling(payment_method_details.billing_details);
      setPayment(payment_method_details.payment_details);
      setLoading(false);
    } catch (error) {
      console.log(error);
      const message = error.response?.data?.msg;
      setErrorMsg(message);
      // toast.error(message);
    }
  };

  const addressParts = [
    billing?.address?.line1,
    billing?.address?.line2,
    billing?.address?.city,
    billing?.address?.state,
    billing?.address?.postal_code,
    billing?.address?.country,
  ];
  const fullAddress = addressParts.filter(Boolean).join(", ");

  const getCardIcon = (brand) => {
    switch (brand?.toLowerCase()) {
      case "visa":
        return <FaCcVisa className="inline text-blue-600 text-xl ml-2" />;
      case "mastercard":
        return <FaCcMastercard className="inline text-red-600 text-xl ml-2" />;
      case "amex":
      case "american express":
        return <FaCcAmex className="inline text-indigo-600 text-xl ml-2" />;
      case "discover":
        return <FaCcDiscover className="inline text-orange-500 text-xl ml-2" />;
      case "rupay":
        return <SiRupay className="inline text-green-600 text-xl ml-2" />;
      default:
        return null;
    }
  };

  const renewSubscription = async () => {
    try {
      let formData = new FormData();
       formData.append("redirect_url", `${process.env.NEXT_PUBLIC_DOMAIN_URL}license`);
     // formData.append("redirect_url", `http://localhost:3000/license/`);

      const response = await axios.post(
        `/api/license/key/subscription/reactivate/${id}/`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // ✅ Open in new tab
      // window.open(response?.data?.url, "_blank");
      // OR open in same tab
      window.location.href = response?.data?.url;
    } catch (error) {
      console.log(error);
      toast.error(error?.response?.data?.msg);
    }
  };

  return (
    <>
      {errorMsg && (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
          {/* Header Section */}
          <div className="bg-white shadow-sm border-b">
            <div className="bg-white shadow-sm border-b">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <Breadcrumb
                  prev="License"
                  current="Details"
                  prevLink="/license"
                />
                <div className="mt-4">
                  <h1 className="text-3xl font-bold text-gray-900">
                    License Details
                  </h1>
                  <p className="mt-2 text-gray-600 text-center">{errorMsg}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        {/* Header Section */}
        <div className="bg-white shadow-sm border-b">
          <div className="bg-white shadow-sm border-b">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
              <Breadcrumb
                prev="License"
                current="Details"
                prevLink="/license"
              />
              <div className="mt-4">
                <h1 className="text-3xl font-bold text-gray-900">
                  License Details
                </h1>
                <p className="mt-2 text-gray-600">
                  Manage and view your subscription information
                </p>
              </div>
            </div>
          </div>

           {/* Loader */} 
{isLoading && (<div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
        <p className="mt-4 text-gray-600">Loading...</p>
      </div>
    </div>)}
          

          {/* Main Content */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

              
              {/* Plan Details Card */}
              {plan && (
                <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                    <CardTitle className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg">
                        <Package className="h-6 w-6" />
                      </div>
                      Plan Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Plan Name</span>
                        <Badge variant="secondary" className="font-semibold">
                          {plan.name}
                        </Badge>
                      </div>
                      <Separator />
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Amount</span>
                        <span className="text-2xl font-bold text-green-600">
                          ${(plan.amount / 100).toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Billing Cycle</span>
                        <span className="font-medium capitalize text-black">
                          {plan.interval_count > 1
                            ? `${plan.interval_count} `
                            : ""}
                          {plan.interval}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Count</span>
                        <span className="font-medium uppercase text-black">
                          {plan.interval_count}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Currency</span>
                        <span className="font-medium uppercase text-black">
                          {plan.currency}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Subscription Details Card */}
              {subscription && (
                <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <CardHeader className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                    <CardTitle className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg">
                        <FileText className="h-6 w-6" />
                      </div>
                      Subscription Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Status</span>
                        <Badge
                          className={`flex items-center gap-1 font-medium px-2 py-1 rounded-md ${
                            subscription.status === "active"
                              ? "bg-green-100 text-green-800 hover:bg-green-100"
                              : "bg-red-100 text-red-800 hover:bg-red-100"
                          }`}
                        >
                          <CheckCircle
                            className={`h-4 w-4 ${
                              subscription.status === "active"
                                ? "text-green-600"
                                : "text-red-600"
                            }`}
                          />
                          {subscription.status}
                        </Badge>
                      </div>
                      {subscription.status !== "active" && (
                        <button
                          className="bg-green-200 p-2 text-xs rounded"
                          onClick={() => renewSubscription()}
                        >
                          Renew Subscription
                        </button>
                      )}

                      <Separator />
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Subscription ID</span>
                        <code className="text-sm bg-gray-100 px-2 py-1 rounded text-black">
                          {subscription.id}
                        </code>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Created</span>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400 " />
                          <span className="text-black">
                            {new Date(
                              subscription.created * 1000
                            ).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      {!subscription.cancel_at_period_end ? (
                        <>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">
                              Current Period
                            </span>
                            <span className="text-sm text-black">
                              {new Date(
                                subscription.current_period_start * 1000
                              ).toLocaleDateString()}{" "}
                              -{" "}
                              {new Date(
                                subscription.current_period_end * 1000
                              ).toLocaleDateString()}
                            </span>
                          </div>
                        </>
                      ) : (
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Valid Until</span>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-orange-500" />
                            <span className="text-black">
                              {new Date(
                                subscription.cancel_at_period_end * 1000
                              ).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      )}

                      {/* <div className="flex justify-between items-center">
                    <span className="text-gray-600">License Key</span>
                    <code className="text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">
                      {subscription.metadata.license_key_id}
                    </code>
                  </div> */}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Payment Details Card */}
              {payment && (
                <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                    <CardTitle className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg">
                        <CreditCard className="h-6 w-6" />
                      </div>
                      Payment Method
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Card Type</span>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl ">
                            {getCardIcon(payment.brand)}
                          </span>
                          <span className="font-medium capitalize text-black">
                            {payment.brand}
                          </span>
                        </div>
                      </div>
                      <button
                        className="bg-green-200 p-2 text-xs rounded"
                        onClick={() => {
                          onOpenChange(true);
                        }}
                      >
                        {" "}
                        Change Card
                      </button>
                      <Separator />
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Card Number</span>
                        <span className="font-mono text-black">
                          •••• •••• •••• {payment.last4}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Expires</span>
                        <span className="font-mono text-black">
                          {payment.exp_month.toString().padStart(2, "0")}/
                          {payment.exp_year}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Type</span>
                        <Badge variant="outline" className="capitalize">
                          {payment.funding}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Country</span>
                        <span className="font-medium ">{payment.country}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              {/* Billing Details Card */}
              {billing && (
                <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <CardHeader className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                    <CardTitle className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg">
                        <Receipt className="h-6 w-6" />
                      </div>
                      Billing Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Name</span>
                        <span className="font-medium text-black">
                          {billing.name}
                        </span>
                      </div>
                      <Separator />
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Email</span>
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-gray-400" />
                          <span className="text-blue-600 ">
                            {billing.email ? billing.email : "NA"}
                          </span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Phone</span>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-gray-400" />
                          <span className="text-black">
                            {billing.phone ? billing.phone : "NA"}
                          </span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Tax ID</span>
                        <div className="flex items-center gap-2">
                          <Hash className="h-4 w-4 text-gray-400" />
                          <span className="font-mono text-black">
                            {billing.tax_id ? billing.tax_id : "NA"}
                          </span>
                        </div>
                      </div>
                      {fullAddress && (
                        <div className="pt-2">
                          <div className="flex items-start gap-2">
                            <MapPin className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                            <div>
                              <span className="text-gray-600 text-sm block">
                                Address
                              </span>
                              <span className="text-sm leading-relaxed text-black">
                                {fullAddress}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
        <CardDetailsPopup isOpen={isOpen} onOpenChange={onOpenChange} />
      </div>
    </>
  );
}
