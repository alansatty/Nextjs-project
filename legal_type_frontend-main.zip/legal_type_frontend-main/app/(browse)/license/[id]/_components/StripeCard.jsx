"use client";
import { useStripe, useElements, CardElement } from "@stripe/react-stripe-js";
import { useState } from "react";
import axios from "@/lib/axios";
import { useParams, useRouter } from "next/navigation";
import { useSession } from "next-auth/react";


export default function StripeCard({ clientSecret }) {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const { data: user } = useSession();
  const token = user?.user?.token;
  const { id } = useParams();
  const router = useRouter();
  const paymentDetailsPost = async (paymentMethodId) => {
 
    try {
      let formData = new FormData();
      formData.append("payment_method_id", `${paymentMethodId}`);
  
      const response = await axios.post(
        `/api/license/key/subscription/payment_method/${id}/update/`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      window.location.href = `/license/${id}`;

    } catch (error) {
      console.log(error);
    }
  };
  
  

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const result = await stripe.confirmCardSetup(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
        },
      });

      if (result.error) {
        setError(error.message);
      } else {
        const paymentMethodId = result.setupIntent.payment_method;
     //   console.log("Saved card id:", paymentMethodId);
        paymentDetailsPost(paymentMethodId);
      }
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <CardElement className="p-2 border rounded" />
      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
          {error}
        </div>
      )}
      <button
        type="submit"
        className="bg-green-600 text-white px-4 py-2 rounded"
        disabled={!stripe || !clientSecret}
      >
        Save Card
      </button>
    </form>
  );
}
