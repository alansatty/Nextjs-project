"use client";

import {
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  useDisclosure,
} from "@nextui-org/react";
import axios from "@/lib/axios";
import { useSession } from "next-auth/react";
import { useParams } from "next/navigation";
import { useEffect } from "react";
import StripeCard from "./StripeCard";
import { StripeElementsWrapper, usePayment } from "@/providers/StripProvider";

export default function CardDetailsPopup({ isOpen, onOpenChange }) {
  const { data: user } = useSession();
  const token = user?.user?.token;
  const { id } = useParams();
  const { clientSecret, setClientSecret } = usePayment();

  const cardDetails = async () => {
    try {
      const response = await axios.get(
        `/api/license/key/subscription/payment_method/${id}/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setClientSecret(response.data.intent_response.client_secret);
     
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    cardDetails();
    return () => {};
  }, [id]);
  return (
    <>
      <Modal isOpen={isOpen} onOpenChange={onOpenChange}>
        <ModalContent>
          {(onClose) => (
            <>
              <ModalHeader className="flex flex-col gap-1">
        <h2 className="text-black">Card Details</h2>
              </ModalHeader>
              <ModalBody className="m-5">
                <StripeElementsWrapper clientSecret={clientSecret}>
                  <StripeCard clientSecret={clientSecret} />
                </StripeElementsWrapper>
              </ModalBody>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
}
