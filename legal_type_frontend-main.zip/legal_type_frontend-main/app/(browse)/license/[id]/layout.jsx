import StripeProvider from "@/providers/StripProvider";
import React from "react";

function layout({ children }) {
  return <StripeProvider>{children}</StripeProvider>;
}

export default layout;
