
import React from "react";
import LicenseTable from "./_components/LicenseTable";
import Breadcrumb from "@/app/components/breadcrumbs";

export const metadata = {
  title: "LegalType | Manage License | Dashboard",
  description: "Easily manage your LegalType license with our user-friendly dashboard, designed to keep your legal tools in check.",
  keywords: ["manage license", "LegalType", "dashboard"], 
};

function LicensePage() {
  return (
    <div className="bg-gray-200 h-full ">
      <div className="pt-12 pl-12">
        <Breadcrumb prev={"Software"} current={"License key"} prevLink={"/"} />{" "}
      </div>

      <div className="text-black mt-5 mb-5 md:mt-0  md:p-12 border  flex justify-center ">
        <div className="w-11/12 bg-white shadow-md  rounded-md p-4 md:p-6">
          <LicenseTable />
        </div>
      </div>
    </div>
  );
}

export default LicensePage;
