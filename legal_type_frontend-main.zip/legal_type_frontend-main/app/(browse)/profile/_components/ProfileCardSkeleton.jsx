import { Skeleton } from '@nextui-org/react';

const ProfileSkeleton = () => {
  return (
    <div className="w-10/12 mx-auto bg-white rounded-md shadow-md p-6">
      <Skeleton className="h-6 w-1/3 mb-4" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <Skeleton className="h-12 w-full mb-4" />
        </div>
        <div>
          <Skeleton className="h-12 w-full mb-4" />
        </div>
        <div>
          <Skeleton className="h-12 w-full mb-4" />
        </div>
      </div>

      <Skeleton className="h-10 w-1/4 mb-8" />

      <Skeleton className="h-6 w-1/3 mb-4" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <Skeleton className="h-12 w-full mb-4" />
        </div>
        <div>
          <Skeleton className="h-12 w-full mb-4" />
        </div>
      </div>

      <Skeleton className="h-10 w-1/4" />
    </div>
  );
};

export default ProfileSkeleton;
