"use client";
import { Input } from "@nextui-org/react";
import { signOut, useSession } from "next-auth/react";
import React, { useEffect, useState } from "react";
import axios from "@/lib/axios";
import { getSelfUser } from "@/lib/util";
import toast from "react-hot-toast";
import { ProfileSchema } from "@/validationSchema/authValidation";
import ProfileSkeleton from "./ProfileCardSkeleton";
import { EyeSlashFilledIcon } from "@/app/assets/icon/EyeSlashFilledIcon";
import { EyeFilledIcon } from "@/app/assets/icon/EyeFilledIcon";
function ProfileCard() {
  const { data: user } = useSession();

  const InputClassNames = (error) => ({
    label: "text-black/50 ",
    input: ["bg-white", "text-black/90 "],
    innerWrapper: "bg-white",
    inputWrapper: [
      "rounded-md",
      "bg-white-200/50",
      error ? "border-red-500" : "group-data-[focus=true]:border-[#1BD1D8B2]",
    ],
    errorMessage: "text-red-500",
  });

  const [name, setName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [nameError, setNameError] = useState("");
  const [lastNameError, setLastNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [confirmPasswordError, setConfirmPasswordError] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isValueUpdated, setIsValueUpdated] = useState(false);
  const [organization , setOrganization] = useState("")
  const [organizationErr, setOrganizationErr] = useState("")

  useEffect(() => {
    if (user?.user) {
      getUser();
    }
  }, [user]);

  async function getUser() {
    const userDetails = await getSelfUser(
      user?.user.token,
      user?.user?.data?.memberplatform_id
    );
    if (userDetails?.memberinformation_deatails) {
      setName(userDetails?.memberinformation_deatails?.first_name);
      setLastName(userDetails?.memberinformation_deatails?.last_name);
      setEmail(userDetails?.memberinformation_deatails?.email_id);
      setOrganization(userDetails?.memberinformation_deatails?.organization_name)
    }
    setIsLoading(false);
  }

  const validateName = (value) => {
    ProfileSchema.validateAt("firstname", { firstname: value })
      .then(() => setNameError(""))
      .catch((err) => setNameError(err.message));
  };

  const validateLastName = (value) => {
    ProfileSchema.validateAt("lastname", { lastname: value })
      .then(() => setLastNameError(""))
      .catch((err) => setLastNameError(err.message));
  };

  const validateEmail = (value) => {
    ProfileSchema.validateAt("email", { email: value })
      .then(() => setEmailError(""))
      .catch((err) => setEmailError(err.message));
  };

  const validatePassword = (value) => {
    ProfileSchema.validateAt("password", { password: value })
      .then(() => setPasswordError(""))
      .catch((err) => setPasswordError(err.message));
  };

  const validateConfirmPassword = (value) => {
    if (value !== password) {
      setConfirmPasswordError("Passwords do not match");
    } else {
      ProfileSchema.validateAt("confirmPassword", { confirmPassword: value })
        .then(() => setConfirmPasswordError(""))
        .catch((err) => setConfirmPasswordError(err.message));
    }
  };


  const validateOrganization = (value) => {
    ProfileSchema.validateAt("organization", { organization: value })
    .then(() => setOrganizationErr(""))
    .catch((err) => setOrganizationErr(err.message));
  }

  const [isVisible, setIsVisible] = useState(false);
  const toggleVisibility = () => setIsVisible(!isVisible);

  const [confirmIsVisible, setConfirmIsVisible] = useState(false);
  const ConfirmToggleVisibility = () => setConfirmIsVisible(!confirmIsVisible);

  const handleUpdateChanges = async () => {
    try {
      validateName(name);
      validateEmail(email);
      validateLastName(lastName);
      validateOrganization(organization)

      if (nameError || organizationErr || emailError || lastNameError || !isValueUpdated) {
        return;
      }

      const token = user?.user?.token;
      const memberPlatformId = user?.user?.data?.memberplatform_id;

      if (!token || !memberPlatformId) {
        throw new Error("Invalid token or memberPlatformId");
      }

      const updateData = {
        first_name: name,
        last_name: lastName,
        email_id: email,
        organization_name:organization
      };
      const { data } = await axios.put(
        `/api/member/update/${memberPlatformId}/`,
        updateData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (data?.data?.memberinformation_deatails) {
        toast.success(data?.msg);

        setTimeout(() => {
          signOut();
        }, 2000);
      }
    } catch (error) {
      console.log(error);
      let errMsg = error?.response?.data.msg;
      toast.error(errMsg);
    }
  };

  const handleResetPassword = async () => {
    try {
      validatePassword(password);
      validateConfirmPassword(confirmPassword);

      if (passwordError || confirmPasswordError || !isValueUpdated) {
        return;
      }

      const token = user?.user?.token;
      const memberPlatformId = user?.user?.data?.memberplatform_id;
      if (!token || !memberPlatformId) {
        throw new Error("Invalid token or memberPlatformId");
      }

      if (password == confirmPassword) {
        const formData = new FormData();
        formData.append("password", password);
        const { data } = await axios.patch(`/api/password/update/`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        toast.success(data?.msg);

        setTimeout(() => {
          signOut();
        }, 2000);
      }
    } catch (error) {
      console.log(error);
      let errMsg = error?.response?.data.msg;
      toast.error(errMsg || "Failed to update");
    }
  };

  if (isLoading) {
    return <ProfileSkeleton />;
  }

  return (
    <div className="w-10/12 mx-auto bg-white rounded-md shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4 text-black">Profile Details</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <Input
            value={name}
            type="text"
            classNames={InputClassNames(!!nameError)}
            variant="bordered"
            size="lg"
            labelPlacement="outside"
            label="First Name"
            isInvalid={nameError ? true : false}
            placeholder="Enter your name"
            color={nameError ? "default" : "default"}
            errorMessage={nameError}
            onValueChange={(value) => {
              setName(value);
              validateName(value);
              setIsValueUpdated(true);
            }}
          />
        </div>
        <div>
          <Input
            value={lastName}
            type="text"
            classNames={InputClassNames(!!lastNameError)}
            variant="bordered"
            size="lg"
            labelPlacement="outside"
            label="Last Name"
            isInvalid={lastNameError ? true : false}
            placeholder="Enter your name"
            color={lastNameError ? "default" : "default"}
            errorMessage={lastNameError}
            onValueChange={(value) => {
              setLastName(value);
              validateLastName(value);
              setIsValueUpdated(true);
            }}
          />
        </div>
        <div>
          <Input
            value={email}
            type="email"
            classNames={InputClassNames(!!emailError)}
            isInvalid={emailError ? true : false}
            variant="bordered"
            size="lg"
            labelPlacement="outside"
            label="Email"
            placeholder="Enter your email"
            color={emailError ? "danger" : "default"}
            errorMessage={emailError}
            onValueChange={(value) => {
              setEmail(value);
              validateEmail(value);
              setIsValueUpdated(true);
            }}
          />
        </div>

        <div>
          <Input
            value={organization}
            type="text"
            classNames={InputClassNames(!!organizationErr)}
            isInvalid={organizationErr ? true : false}
            variant="bordered"
            size="lg"
            labelPlacement="outside"
            label="Organization Name"
            placeholder="Enter Organization"
            color={organizationErr ? "danger" : "default"}
            errorMessage={organizationErr}
            onValueChange={(value) => {
              setOrganization(value);
              validateOrganization(value);
              setIsValueUpdated(true);
            }}
          />
        </div>
      </div>

      <button
        onClick={handleUpdateChanges}
        className="rounded-[2px] uppercase bg-[#1BD1D8] text-black font-medium px-10 py-2 mb-8"
      >
        Update Changes
      </button>

      <h2 className="text-xl font-semibold mb-4 text-black">Change Password</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <Input
            value={password}
            classNames={InputClassNames(!!passwordError)}
            isInvalid={passwordError ? true : false}
            variant="bordered"
            size="lg"
            labelPlacement="outside"
            label="New Password"
            placeholder="Enter new password"
            color={passwordError ? "danger" : "default"}
            errorMessage={passwordError}
            onValueChange={(value) => {
              setPassword(value);
              validatePassword(value);
              setIsValueUpdated(true);
            }}
            endContent={
              <button
                className="focus:outline-none"
                type="button"
                onClick={toggleVisibility}
                aria-label="toggle password visibility"
              >
                {isVisible ? (
                  <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                ) : (
                  <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                )}
              </button>
            }
            type={isVisible ? "text" : "password"}
          />
        </div>
        <div>
          <Input
            value={confirmPassword}
            classNames={InputClassNames(!!confirmPasswordError)}
            isInvalid={confirmPasswordError ? true : false}
            variant="bordered"
            size="lg"
            labelPlacement="outside"
            label="Confirm Password"
            placeholder="Confirm new password"
            color={confirmPasswordError ? "danger" : "default"}
            errorMessage={confirmPasswordError}
            onValueChange={(value) => {
              setConfirmPassword(value);
              validateConfirmPassword(value);
              setIsValueUpdated(true);
            }}
            endContent={
              <button
                className="focus:outline-none"
                type="button"
                onClick={ConfirmToggleVisibility}
                aria-label="toggle password visibility"
              >
                {confirmIsVisible ? (
                  <EyeSlashFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                ) : (
                  <EyeFilledIcon className="text-2xl text-default-400 pointer-events-none" />
                )}
              </button>
            }
            type={confirmIsVisible ? "text" : "password"}
          />
        </div>
      </div>

      <button
        onClick={handleResetPassword}
        className="rounded-[2px] uppercase bg-[#1BD1D8] text-black font-medium px-10 py-2 mb-8"
      >
        Reset Password
      </button>
    </div>
  );
}

export default ProfileCard;
