import React from "react";
import ProfileCard from "./_components/ProfileCard";
import Breadcrumb from "@/app/components/breadcrumbs";
const ProfilePage = () => {

  return (
    <div className="bg-gray-200 min-h-screen p-6">
      <nav className="text-sm text-gray-600 mb-6 px-4">
        <Breadcrumb prev={"Software"} current={"Profile"} prevLink={'/'}/>
      </nav>
      <ProfileCard />
    </div>
  );
};

export default ProfilePage;
