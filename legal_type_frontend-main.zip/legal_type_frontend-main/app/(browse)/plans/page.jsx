import React from "react";
import SubscriptionPlans from "../_components/SubscriptionPlans";
import Breadcrumb from "@/app/components/breadcrumbs";
import AosWrapper from "@/app/components/AosWrapper";

export const metadata = {
  title: "Legal Writing Software | Free Download | California",
  description: "Discover LegalType Plans featuring premium legal writing software available as a free download, crafted for attorneys in California.",
  keywords: ["legal writing software", "free download", "California"],
};

function PlanPage() {
  return (
    <AosWrapper>
      <div className="bg-white h-full">
        <div className="p-8">
          <Breadcrumb
            prev={"Software"}
            current={"Subscription Plans"}
            prevLink={"/"}
          />
        </div>
        <div data-aos="fade-up">
          <SubscriptionPlans />
        </div>
      </div>
    </AosWrapper>
  );
}

export default PlanPage;
