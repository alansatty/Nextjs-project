import HeroSection from "./_components/HeroSection";
import Features from "./_components/Features";
import LegalSoftwareSection from "./_components/LegalSoftwareSection";
import HowToUseSection from "./_components/HowToUseSection";
import TestimonialsSection from "./_components/TestimonialSection";
import SubscriptionPlans from "../_components/SubscriptionPlans";
import AosWrapper from "@/app/components/AosWrapper";

const baseUrl = process.env.NEXT_PUBLIC_DOMAIN_URL;

export const metadata = {
  title: "LegalType | Lawyer Keyboard | California",
  description:
    "Explore LegalType a cutting-edge lawyer keyboard designed specifically for legal professionals in California.",
  keywords: [
    "LegalType",
    "lawyer keyboard",
    "California",
    "windows shortcut keys for lawyers",
    "lawyer",
    "free download",
    "alt codes and legal symbols",
  ],
  openGraph: {
    images: [
      `${baseUrl}images/laptop.png`,
      `${baseUrl}images/lawyer.png`,
      `${baseUrl}images/cardIma`,
      `${baseUrl}images/cardImages/download-free-now.svg`,
      `${baseUrl}images/cardImages/purchase-software-license.svg`,
      `${baseUrl}images/cardImages/manage-software-key.svg`,
    ],
  },
};

function Home() {
  return (
    <AosWrapper>
      <div data-aos="fade-down">
        <HeroSection />
      </div>
      <div data-aos="fade-up">
        <Features />
      </div>
      <div data-aos="fade-down">
        <LegalSoftwareSection />
      </div>
      <div data-aos="fade-right">
        <HowToUseSection />
      </div>
      <div data-aos="fade-down">
        <TestimonialsSection />
      </div>
      <div data-aos="fade-up">
        <SubscriptionPlans />
      </div>
    </AosWrapper>
  );
}

export default Home;
