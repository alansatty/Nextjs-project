"use client";
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import { CircleArrowLeft, CircleArrowRight, QuoteIcon } from "lucide-react";

let testimonialsData = [
  {
    content:
      "Makes Drafting a Breeze. The Outlook and Word specific macros are a game changer. If you spend hours redlining and editing documents, this keyboard has the potential to significantly boost your efficiency. Being able to add a footnote or comment or bulleted list in a WordDoc or Email without touching my mouse has made editing so much more enjoyable.",
    name: "James Dewey",
    position: "Commercial Cannabis Attorney",
  },
  {
    content:
      "I cannot imagine a world without the keyboard now. It saves me so much time at work with formatting and track changes. I love the look and feel of it. My favorite part are the pilcrow and silcrow keys.",
    name: "Jacob Malafsky",
    position: "Supervising Attorney at Queens Legal Services",
  },
  {
    content:
      "Things should look good, feel good and work well, and this keyboard does all three... it has been a great boon to my legal writing.",
    name: "Brendan Kenny",
    position: "Trial Lawyer, Legal Writer, Persuasion-ist: Hellmuth & Johnson",
  },
  {
    content:
      "I’ve looked at other legal keyboards and they’re designed either by or for litigators. LegalType is the only one I’ve seen that is easily customizable. It worked well when I got it, but after my customizations, it’s even faster and easier than dictation, and I don’t have to hire a transcriptionist.",
    name: "Cassady Toles",
    position: "Oakland-based transactional attorney",
  },
  {
    content:
      "LegalType is intuitive and a much-needed simplification to legal writing formatting. I highly recommend this software for anyone in the legal profession. This software is exactly what I needed to simplify legal writing and the associated formatting.",
    name: "Dawson O",
    position: "Associate/Staff attorney Criminal",
  },
  {
    content:
      "LegalType has improved my typing rate and task completion time. I can edit documents much more easily by using shortcut features. I was interested in the product since LegalType integrates design with performance. The spacing of keys allows smooth hand travel hence fast typing and error reduction. I'm also impressed by the appearance of the product.",
    name: "Wyatt K",
    position: "Consultant/Analyst",
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-16 bg-[#F8F8F8] text-black">
      <div className="container mx-auto px-4">
        {/* Heading */}
        <h5 className="text-[#1BD1D8] text-center text-medium font-semibold uppercase mb-2">
          Testimonials
        </h5>

        {/* Big Title */}
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
          Customer Reviews
        </h2>

        {/* Carousel */}
        <div className="relative">
          <Swiper
            modules={[Navigation, Pagination, Autoplay]}
            spaceBetween={20}
            slidesPerView={1}
            loop={true}
            autoplay={{ delay: 5000, disableOnInteraction: false }}
            pagination={{ clickable: true }}
            navigation={{
              prevEl: ".swiper-button-prev",
              nextEl: ".swiper-button-next",
            }}
            className="swiper-container"
          >
            {testimonialsData?.map((data) => {
              return (
                <SwiperSlide>
                  <div className="p-6 md:px-14 lg:p-6 bg-white rounded-lg shadow-md text-center max-w-3xl mx-auto">
                    <div className="flex justify-center">
                      <div className="mb-2 text-2xl">
                        <QuoteIcon
                          fill="#1BD1D8"
                          className="text-[#1BD1D8] w-10 h-10 mb-4"
                        />
                      </div>
                    </div>

                    <p className="text-black mb-2 break-words text-sm md:text-base">
                      {data.content}
                    </p>
                    <h3 className="text-lg font-semibold">{data.name}</h3>
                    <p className="text-gray-500 text-sm">{data.position}</p>
                  </div>
                </SwiperSlide>
              );
            })}
          </Swiper>

          {/* Navigation Buttons */}
          <div className="absolute top-1/2 left-4 transform -translate-y-1/2 z-10 hidden md:block">
            <CircleArrowLeft className="swiper-button-prev text-gray-400 hover:cursor-pointer h-10 w-10" />
          </div>
          <div className="absolute top-1/2 right-4 transform -translate-y-1/2 z-10 hidden md:block">
            <CircleArrowRight className="swiper-button-next text-gray-400 hover:cursor-pointer h-10 w-10" />
          </div>
        </div>
      </div>
    </section>
  );
}
