import { Button } from "@nextui-org/react";
import { CircleCheckBigIcon, Download } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import React from "react";

function HeroSection() {
  return (
    <section
      className="py-7 lg:py-16 lg:relative overflow-x-hidden overflow-y-hidden"
      style={{
        backgroundImage: 'url("/images/Hero-Banner_new.svg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        width: '100%',
        // height: '100vh',
      }}
    
    >
      <div className="container mx-auto flex flex-col-reverse lg:flex-row items-center justify-between pr-0 px-4">
        {/* Left Side */}
        <div className="lg:w-1/2 p-3 md:p-0 text-white space-y-6">
          <div className="inline-block   text-black py-2  text-2xl font-bold  ">
             Activate Your LegalType Keyboard
          </div>

          <h1 className="text-4xl font-semibold">
            Register, Purchase or Manage Your Software
          </h1>

          <p className="leading-relaxed">
          Ready to make document drafting a breeze? Tired of navigating through rabbit holes in Microsoft Word? Let us help you produce more content with less typing, so you can focus on what matters most winning.
          </p>

          <ul className="space-y-3">
            <li className="flex items-center">
              <span className=" text-white rounded-full p-2 mr-3">
                <CircleCheckBigIcon />
              </span>
              Automate repetitive tasks.
            </li>
            <li className="flex items-center">
              <span className=" text-white rounded-full p-2 mr-3">
                <CircleCheckBigIcon />
              </span>
              Eliminate wrist pain.
            </li>
            <li className="flex items-center">
              <span className=" text-white rounded-full p-2 mr-3">
                <CircleCheckBigIcon />
              </span>
              Focus on legal writing, not document assembly.
            </li>
          </ul>

           
          <div>
          <Link
            href="/plans" className="mt-6 rounded-[2px] bg-[#1BD1D8] text-black py-3 px-5 font-medium uppercase">
          Download
          </Link>
          </div> 

          {/* <Link
            href="/plans"
            className="relative inline-flex items-center justify-center overflow-hidden  p-[2px] uppercase"
          >
            <span className="absolute rounded-[2px] inset-0 bg-gradient-to-r from-[#1BD1D8] via-[#F06BDA] to-[#E2CBFF] "></span>
            <span className="relative  inline-flex items-center justify-center gap-2  bg-[#1BD1D8] px-6 py-3 text-md font-medium text-black backdrop-blur-md">
            
              <span>Download</span>
            </span>
          </Link> */}

          {/* 
          <Link
            href="/plans"
            className="relative inline-flex items-center justify-center overflow-hidden rounded-full p-[1px] focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50"
          >
            <span className="absolute -inset-1 animate-spin-slow bg-gradient-to-r from-[#1BD1D8] via-[#F06BDA] to-[#E2CBFF] opacity-75"></span>
            <span className="relative inline-flex items-center justify-center gap-2 rounded-full bg-[#5b137cc9] px-6 py-3 text-md font-medium text-white backdrop-blur-md">
              <Download className="h-5 w-5" />
              <span>Download</span>
            </span>
          </Link> */}
        </div>

        {/* Right Side */}
        <div className="md:w-1/2  flex justify-center md:justify-end mb-8 md:mb-0 ">
          {/* <Image
            src="/images/Ellipse.svg" // Replace with your image path
            alt="Software Image"
            width={600}
            height={600}
            className="object-contain lg:absolute lg:right-[-48px] lg:top-24 hidden"
            style={{ opacity: 0.7 }}
            // style={{ mixBlendMode: 'overlay', backgroundColor: 'rgba(0, 0, 0, 0)' }}
          /> */}
          <Image
            src="/images/laptop.png" // Replace with your image path
            alt="windows shortcut keys"
            width={700}
            height={700}
            className="opacity-90 md:opacity-100 object-contain hidden lg:absolute lg:-right-28 xl:right-0 lg:bottom-16 lg:block"
          />
        </div>
      </div>
    </section>
  );
}

export default HeroSection;
