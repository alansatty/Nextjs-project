import Image from "next/image";
import React from "react";

export default function HowToUseSection() {
  return (
    // <section className="py-16 bg-gradient-to-tr from-[#f06bda4b] via-black to-[#f06bda25] text-white">
    <section
      className="py-16 lg:relative overflow-x-hidden overflow-y-hidden text-white"
      style={{
        backgroundImage: 'url("/images/getStartBg.svg")',
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        width: "100%",
        // height: '100vh',
      }}
    >
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-3xl font-bold mb-4">
          How to Get Started
        </h2>
        <p className="mb-12">
          Download LegalType free for one month. A manual and security document
          are included in the download.
        </p>

        <div className="flex flex-wrap justify-center gap-8">
          {/* Card 1 */}
          <div className="bg-white text-black rounded-lg shadow-lg  max-w-sm w-full">
            <div className="mt-3 rounded-lg flex justify-center">
              <Image
                src="/images/cardImages/download-free-now.svg"
                alt="free download"
                className="w-32 h-36 object-cover rounded-lg"
                width={100}
                height={100}
              />
            </div>
            <div className="p-6 text-start">
              <h3 className="text-xl font-semibold mb-2">Download Free Now</h3>
              <p className="text-black">
                No credit card required. Upgrade to a one-time payment or
                pay-as-you go plan after 30 days.
              </p>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white text-black rounded-lg shadow-lg  max-w-sm w-full">
            <div className="mt-3 rounded-lg flex justify-center">
              <Image
                src="/images/cardImages/purchase-software-license.svg"
                alt="windows shortcut keys for lawyers"
                className="w-32 h-36 object-cover rounded-lg"
                width={100}
                height={100}
              />
            </div>
            <div className="p-6 text-start">
              <h3 className="text-xl font-semibold mb-2">
                Purchase Software License
              </h3>
              <p className="text-black">
                Visit the "Purchase License" page, choose your plan, and
                complete the payment. You will receive your license via email
                and can also find it in your profile.
              </p>
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white text-black rounded-lg shadow-lg  max-w-sm w-full">
            <div className="rounded-lg flex justify-center mt-3">
              <Image
                src="/images/cardImages/manage-software-key.svg"
                alt="alt codes and legal symbols"
                className="w-32 h-36 object-cover rounded-lg"
                width={100}
                height={100}
              />
            </div>
            <div className="p-6 text-start">
              <h3 className="text-xl font-semibold mb-2">
                Manage Software Key
              </h3>
              <p className="text-black">
                Log in to your profile to view and manage your licenses. Set
                your license to auto renew to ensure uninterrupted access.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
