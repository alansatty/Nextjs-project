"use client"
import React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function LegalSoftwareSection() {
   const router =  useRouter()
  return (
    <section className="py-16 bg-white relative overflow-hidden">
      <div className=" flex flex-col md:flex-row items-center justify-between ">
        {/* Left Side */}
        <div className="relative md:w-1/2 mb-8 md:mb-0">
          <div className="relative w-full h-[19rem] md:h-auto bg-cover bg-center overflow-hidden">
            <Image
              src="/images/lawyer.jpg" // Ensure this path is correct
              alt="lawyer"
              width={700} // Adjust width as needed
              height={600} // Adjust height as needed
              objectFit="contain ml-6"
            />
          </div>
        </div>
        {/* Right Side */}
        <div className="md:w-1/2 text-center md:text-left space-y-3 md:ml-8 px-4 container mx-auto relative z-10">
          <h3 className="text-[#1BD1D8] text-medium font-semibold uppercase">
            LegalType Software
          </h3>
          <h2 className="text-3xl md:text-4xl font-bold leading-tight text-black">
          Legal Writing Made Easy
          </h2>
          <p className="text-black leading-relaxed w-full md:w-[90%]">
          The average executive types for just seven minutes a day, while lawyers type for over three hours daily. While many HR departments allocate budgets for ergonomic keyboards, extensive typing can still lead to injury. LegalType is designed to accelerate typing and document assembly, letting you focus on legal writing without distractions or strain. Reduce your keystrokes and mouse clicks—because no one wants to spend extra time on correspondence or red-lining contracts. We offer both one-time fees and pay-as-you-go options. Book a demo today and discover how our software can be tailored to your legal team.
          </p>
          <button onClick={()=>router.push('/plans')}  className="mt-6 rounded-[2px] bg-[#1BD1D8] text-black py-3 px-5 font-medium uppercase">
           Learn More
          </button>

          <Image
            src="/images/softwareFrame.svg" // Replace with your image path
            alt="Software Image"
            width={300}
            height={300}
            className="opacity-70 md:opacity-100 object-contain hidden lg:absolute right-0 lg:-bottom-[28px] -z-10 lg:block"
          />
        </div>
      </div>
    </section>
  );
}
