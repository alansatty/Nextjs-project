"use client"

import React from 'react';
import { Newspaper, ShieldCheck, DollarSign, Headset } from 'lucide-react';
import { LicenseIcon } from '@/app/assets/icon/LicenseIcon';
import { SecurityIcon } from '@/app/assets/icon/SecurityIcon';
import { CostIcon } from '@/app/assets/icon/CostIcon';
import { CustomerSupportIcon } from '@/app/assets/icon/CustomerSupportIcon';



export default function Features() {
  return (
    <section className="bg-[#F8F8F8] py-12">
      <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0 md:space-x-8">
        

        <div className="flex flex-col items-center text-center w-full md:w-1/4">
          <LicenseIcon className="text-[#1BD1D8] w-12 h-12 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-black">Flexible Licensing</h3>
          <p className="text-black break-normal">
          Choose a one-time payment, or pay-as-you-go.
          </p>
        </div>
        

        <div className="flex flex-col items-center text-center w-full md:w-1/4">
          <SecurityIcon className="text-[#1BD1D8] w-12 h-12 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-black">Enhanced Security</h3>
          <p className="text-black break-normal">
          We don't collect any of your data, ever.
          </p>
        </div>
        

        <div className="flex flex-col items-center text-center w-full md:w-1/4">
          <CostIcon className="text-[#1BD1D8] w-12 h-12 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-black">Cost-Effective</h3>
          <p className="text-black break-normal">
          More features at a lower cost than competitors, with satisfaction guaranteed.
          </p>
        </div>
        

        <div className="flex flex-col items-center text-center w-full md:w-1/4">
          <CustomerSupportIcon className="text-[#1BD1D8] w-12 h-12 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-black">24/7 Customer Support</h3>
          <p className="text-black break-normal">
          Reach out anytime, on any channel.
          </p>
        </div>
      </div>
    </section>
  );
}
