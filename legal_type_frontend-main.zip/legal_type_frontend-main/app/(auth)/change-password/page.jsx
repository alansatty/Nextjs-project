"use client";

import { Card, CardBody, CardHeader } from "@nextui-org/react";
import React, { Suspense } from "react";
import { useForm } from "react-hook-form";
import { changePasswordValidation } from "@/validationSchema/authValidation";
import { yupResolver } from "@hookform/resolvers/yup";
import FormInput from "../../components/input";
import PrimaryButton from "../../components/button";
import axios from "@/lib/axios";
import toast from "react-hot-toast";
import { useRouter, useSearchParams } from "next/navigation";

const ChangePasswordComponent = () => {
  const [loading, setLoading] = React.useState(false);
  const [passIsVisible, setPassIsVisible] = React.useState(false);
  const [confirmPassIsVisible, setConfirmPassIsVisible] = React.useState(false);

  const searchParams = useSearchParams();
  const memberPlatformId = searchParams.get('member_platform_id');

  const router = useRouter()

  const passToggleVisibility = () => setPassIsVisible(!passIsVisible);
  const confirmPassToggleVisibility = () => setConfirmPassIsVisible(!confirmPassIsVisible);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(changePasswordValidation),
  });

  const handleChangePassword = async (data) => {
    if (data) {
      setLoading(true);
      try {
        const formData = new FormData();
        formData.append('member_platform_id', memberPlatformId);
        formData.append('confirm_password', data.confirmPassword);
        formData.append('password', data.password);

        const resetPassRes = await axios.post('api/member_platform_password_verification/', formData);

        console.log("Response for resetPassRes", resetPassRes);

        if (resetPassRes.status == 200) {
          toast.success(resetPassRes.data?.msg);
          setLoading(false);
          router.push('/login')
        }
      } catch (error) {
        console.error("Error:", error);
        toast.error(error.response?.data?.msg);
        setLoading(false);
      }
    }
  };

  return (
    <div className="flex justify-center align-middle bg-white pt-20">
      <Card className="m-2 lg:w-[500px] p-5">
        <CardHeader className="flex flex-col justify-center">
          <h4 className="font-bold text-center text-3xl">Set New Password</h4>
        </CardHeader>
        <CardBody className="mb-5">
          <form onSubmit={handleSubmit(handleChangePassword)}>
            <FormInput
              label="Enter New Password"
              type="password"
              fieldName="password"
              required
              errors={errors}
              register={register}
              isVisible={passIsVisible}
              toggleVisibility={passToggleVisibility}
            />
            <FormInput
              label="Confirm Password"
              type="password"
              fieldName="confirmPassword"
              required
              errors={errors}
              register={register}
              isVisible={confirmPassIsVisible}
              toggleVisibility={confirmPassToggleVisibility}
            />
            <div className="mt-10 text-center">
              <PrimaryButton
                buttonText={"Set Password"}
                className={"w-full bg-[#1BD1D8] rounded-none text-black uppercase font-medium text-large mb-3"}
                isLoading={loading}
              />
            </div>
          </form>
        </CardBody>
      </Card>
    </div>
  );
};

const ChangePassword = () => (
  <Suspense fallback={<div>Loading...</div>}>
    <ChangePasswordComponent />
  </Suspense>
);

export default ChangePassword;
