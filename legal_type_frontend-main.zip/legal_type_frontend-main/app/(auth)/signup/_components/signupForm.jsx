"use client";
import FormInput from "@/app/components/input";
import { signupValidation } from "@/validationSchema/authValidation";
import { yupResolver } from "@hookform/resolvers/yup";
import React from "react";
import { useForm } from "react-hook-form";
import axios from "@/lib/axios";
import { signIn } from "next-auth/react";
import { Checkbox } from "@nextui-org/react";
import Link from "next/link";
import PrimaryButton from "@/app/components/button";
import toast from "react-hot-toast";

const SignupForm = () => {
  const [passIsVisible, setPassIsVisible] = React.useState(false);
  const [confirmPassIsVisible, setConfirmPassIsVisible] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const passToggleVisibility = () => setPassIsVisible(!passIsVisible);
  const confirmPassToggleVisibility = () =>
    setConfirmPassIsVisible(!confirmPassIsVisible);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(signupValidation),
  });

  const handleRegister = async (data) => {
    if (data) {
      setLoading(true);

      console.log(data, "base url", process.env.NEXT_PUBLIC_BASE_API_URL);

      try {
        const formdata = new FormData();
        formdata.append("first_name", data.firstname);
        formdata.append("last_name", data.lastname);
        formdata.append("email_id", data.email);
        formdata.append("password", data.password);
        formdata.append("domain_url", process.env.NEXT_PUBLIC_DOMAIN_URL);

        const signupRes = await axios.post(
          "api/member/registration/",
          formdata
        );

        console.log("responce for signup ", signupRes);

        if (signupRes.status === 200) {
          const credentials = {
            ...data,
            domain_url: process.env.NEXT_PUBLIC_DOMAIN_URL,
            redirect: true,
            callbackUrl: "/license",
          };

          const LoginRes = await signIn("credentials", credentials);

          console.log("responce for login", LoginRes);
        } else {
          console.log("error in signup ", signupRes);
          toast.error(signupRes.response?.data?.msg);
        }
      } catch (error) {
        console.error("Error:", error);
        toast.error(error.response?.data?.msg);
      } finally {
        setLoading(false);
      }
    }
  };
  return (
    <form onSubmit={handleSubmit(handleRegister)}>
      <FormInput
        label="First name"
        type="text"
        fieldName="firstname"
        required
        errors={errors}
        register={register}
      />

      <FormInput
        label="Last name"
        type="text"
        fieldName="lastname"
        errors={errors}
        register={register}
      />

      <FormInput
        label="Email"
        type="email"
        fieldName="email"
        required
        errors={errors}
        register={register}
      />

      <FormInput
        label="Password"
        type="password"
        fieldName="password"
        required
        errors={errors}
        register={register}
        isVisible={passIsVisible}
        toggleVisibility={passToggleVisibility}
      />

      <FormInput
        label="Confirm Password"
        type="password"
        fieldName="confirmPassword"
        required
        errors={errors}
        register={register}
        isVisible={confirmPassIsVisible}
        toggleVisibility={confirmPassToggleVisibility}
      />

      <div className="flex flex-col justify-between mt-5">
        <Checkbox {...register("terms")} isInvalid={errors.terms}>
          I agree with the
          <Link className="text-[#1994C1] hover:underline ms-1" href={"/"}>
            Terms & Conditions
          </Link>
        </Checkbox>

        {errors.terms && (
          <p className="text-tiny text-danger mt-1 ml-6">
            {errors.terms?.message}
          </p>
        )}
      </div>

      <div className="mt-10 text-center">
        <PrimaryButton
          buttonText={"Register"}
          className={
            "w-full bg-[#1BD1D8] rounded-none text-black uppercase font-medium text-large mb-3"
          }
          isLoading={loading}
        />

        <span>
          Already have an account?{" "}
          <Link className="text-[#1994C1] hover:underline" href={"/login"}>
            Log In
          </Link>{" "}
        </span>
      </div>
    </form>
  );
};

export default SignupForm;
