import { Card, CardBody, CardHeader } from "@nextui-org/react";
import React from "react";
import SignupForm from "./_components/signupForm";

export const metadata = {
  title:
    "Try LegalType Free | Free Download | No Credit Card",
  description:
    "Sign up for LegalType today to start your free trial and download our software—no credit card necessary.",
  keywords: ["try LegalType free", "free download", "no credit card"],
};

const signup = () => {
  return (
    <>
      <div className="flex bg-white justify-center align-middle pt-20">
        <Card className="m-2 lg:w-[500px] p-5">
          <CardHeader className="flex justify-center ">
            <h4 className="font-bold text-center text-3xl">
              Create Your Account
            </h4>
          </CardHeader>

          <CardBody className="py-0 mb-5">
            <SignupForm />
          </CardBody>
        </Card>
      </div>
    </>
  );
};

export default signup;
