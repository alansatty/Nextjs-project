import { Card, CardBody, CardHeader } from "@nextui-org/react";
import React from "react";
import LoginForm from "./_components/loginForm";

export const metadata = {
  title: "LegalType | Lawyer | Attorney | Sign in",
  description: "Access your LegalType account using our secure login portal tailored for lawyers and attorneys.",
  keywords: ["LegalType", "lawyer", "attorney", "sign in"],
};

const login = () => {
  return (
    <>
      <div className="flex justify-center bg-white align-middle pt-20">
        <Card className="m-2 lg:w-[500px] p-5">
          <CardHeader className="flex justify-center ">
            <h4 className="font-bold text-center text-3xl">Login</h4>
          </CardHeader>

          <CardBody className="py-0 mb-5">
            <LoginForm />
          </CardBody>
        </Card>
      </div>
    </>
  );
};

export default login;
