"use client";
import PrimaryButton from "@/app/components/button";
import FormInput from "@/app/components/input";
import { loginValidation } from "@/validationSchema/authValidation";
import { yupResolver } from "@hookform/resolvers/yup";
import { Checkbox } from "@nextui-org/react";
import { signIn } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

const LoginForm = () => {
  const [isVisible, setIsVisible] = React.useState(false);
  const router = useRouter();
  const toggleVisibility = () => setIsVisible(!isVisible);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(loginValidation),
  });

  const handleLogin = async (data) => {
    try {
      const credentials = {
        ...data,
        domain_url: process.env.NEXT_PUBLIC_DOMAIN_URL,
        redirect: false, // Set redirect to false to handle manually
      };

      const response = await signIn("credentials", credentials);

      console.log(response);

      if (response?.ok) {
        console.log("ima here");
        window.location.href = "/license";
        router.push("/license");
      } else {
        throw new Error(response?.error || "Login failed");
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <form onSubmit={handleSubmit(handleLogin)}>
      <FormInput
        label="Email"
        type="email"
        fieldName="email"
        required
        errors={errors}
        register={register}
      />

      <FormInput
        label="Password"
        type="password"
        fieldName="password"
        required
        errors={errors}
        register={register}
        isVisible={isVisible}
        toggleVisibility={toggleVisibility}
      />

      <div className="flex flex-col gap-3 md:flex-row justify-between mt-5">
        <Checkbox>Remember me</Checkbox>

        <Link
          className="text-[#1994C1] hover:underline"
          href={"/forgot-password"}
        >
          Forgot Password ?
        </Link>
      </div>

      <div className="mt-10 text-center">
        <PrimaryButton
          buttonText={"Login"}
          className={
            "w-full bg-[#1BD1D8] rounded-none text-black uppercase font-medium text-large mb-3"
          }
        />

        <span>
          Don't have an account?{" "}
          <Link className="text-[#1994C1] hover:underline" href={"/signup"}>
            Sign Up
          </Link>{" "}
        </span>
      </div>
    </form>
  );
};

export default LoginForm;
