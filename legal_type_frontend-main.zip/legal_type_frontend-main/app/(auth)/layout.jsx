import NavbarComponent from "../components/navbar";

const AuthLayout = ({ children }) => {
    return (
        <>
            <NavbarComponent/>
            <div>
            
                {children}
            </div>
        </>
    );
};

export default AuthLayout;