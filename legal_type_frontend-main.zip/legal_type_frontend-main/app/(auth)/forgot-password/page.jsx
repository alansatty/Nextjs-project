"use client";
import { Card, CardBody, CardHeader } from "@nextui-org/react";

import React from "react";
import { useForm } from "react-hook-form";
import { resetPasswordValidation } from "@/validationSchema/authValidation";

import { yupResolver } from "@hookform/resolvers/yup";
import FormInput from "../../components/input";
import PrimaryButton from "../../components/button";
import axios from "@/lib/axios";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";
import Breadcrumb from "@/app/components/breadcrumbs";

const resetPassword = () => {
  const [loading, setLoading] = React.useState(false);
  const router = useRouter()
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(resetPasswordValidation),
  });

  const handleResetPassword = async (data) => {
    if (data) {
      setLoading(true);
      try {

        const formdata = new FormData()
        formdata.append('email_id',data.email)
        formdata.append('domain_url',process.env.NEXT_PUBLIC_DOMAIN_URL)
        formdata.append('password_change_redirect_html_url',`${process.env.NEXT_PUBLIC_DOMAIN_URL}change-password`)

        const resetPassRes = await axios.post('api/forget_password/platform/ways/', formdata);

        console.log("responce for resetPassRes ", resetPassRes);

        if (resetPassRes.status == 200) {
            toast.success(resetPassRes.data?.msg)
            setLoading(false)
            router.push('/login')
        }

      } catch (error) {
        console.error("Error:", error);
        // Handle error, show error message, etc.
        toast.error(error.response?.data?.msg)
        setLoading(false)
      }
    }
  };

  return (
    <>
      <div className="pt-12 pl-12 bg-white">
        <Breadcrumb prev={"Login"} current={"Forgot Password"} prevLink={"/login"} />{" "}
      </div>
      <div className="flex justify-center align-middle pt-10 bg-white">
        <Card className="m-2 lg:w-[500px] p-5">
          <CardHeader className="flex flex-col justify-center ">
            <h4 className="font-bold text-center text-3xl mb-3">Forgot Password?</h4>
            <p>Enter your email to receive a reset link </p>
          </CardHeader>

          <CardBody className=" mb-5">
            <form onSubmit={handleSubmit(handleResetPassword)}>
              <FormInput
                label="Email"
                type="email"
                fieldName="email"
                required
                errors={errors}
                register={register}
              />

              <div className="mt-10 text-center">
                <PrimaryButton
                  buttonText={"Reset Password"}
                  className={"w-full bg-[#1BD1D8] rounded-none text-black uppercase font-medium text-large mb-3"}
                  isLoading={loading}
                />
              </div>
            </form>
          </CardBody>
        </Card>
      </div>
    </>
  );
};

export default resetPassword;
